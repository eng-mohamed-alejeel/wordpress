<?php
/** Router for localhost-only HTTP authentication tests against the disposable database. */
if ( PHP_SAPI !== 'cli-server' ) { http_response_code( 404 ); exit; }
$config = json_decode( base64_decode( (string) getenv( 'ADC_HTTP_TEST_CONFIG' ), true ), true );
if ( ! is_array( $config ) || ! preg_match( '/\Aadc_verify_[a-f0-9]{16}\z/', $config['database'] ?? '' ) ) { http_response_code( 503 ); exit; }
$theme_test = '1' === getenv( 'ADC_THEME_TEST' );
if ( $theme_test ) {
	$asset = (string) parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH );
	if ( 'twentytwentyfive' === getenv( 'ADC_THEME_SLUG' ) && preg_match( '#\A/wp-content/themes/twentytwentyfive/(.+\.(?:css|js|svg|png|jpg|jpeg|webp|woff2?|ttf|otf))\z#i', $asset, $match ) ) {
		$theme_root = realpath( __DIR__ . '/isolated-content/themes/twentytwentyfive' );
		$file = realpath( __DIR__ . '/isolated-content/themes/twentytwentyfive/' . $match[1] );
		if ( ! $theme_root || ! $file || ! str_starts_with( $file, $theme_root . DIRECTORY_SEPARATOR ) || ! is_file( $file ) ) { http_response_code( 404 ); exit; }
		$extension = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
		$types = array( 'css'=>'text/css', 'js'=>'text/javascript', 'svg'=>'image/svg+xml', 'png'=>'image/png', 'jpg'=>'image/jpeg', 'jpeg'=>'image/jpeg', 'webp'=>'image/webp', 'woff'=>'font/woff', 'woff2'=>'font/woff2', 'ttf'=>'font/ttf', 'otf'=>'font/otf' );
		header( 'Content-Type: ' . $types[$extension] ); readfile( $file ); exit;
	}
	if ( preg_match( '#\A/(?:wp-content/(?:themes/car-dealer|plugins/auto-dealership-core/assets)/|wp-includes/).+\.(?:css|js|svg|png|jpg|jpeg|webp|woff2?|ttf|otf)\z#i', $asset ) ) {
		$root = realpath( dirname( __DIR__, 4 ) ); $file = realpath( $root . $asset );
		if ( $file && str_starts_with( $file, $root . DIRECTORY_SEPARATOR ) && is_file( $file ) ) {
			$extension = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
			if ( in_array( $extension, array( 'ttf', 'otf' ), true ) ) { header( 'Content-Type: font/' . $extension ); readfile( $file ); exit; }
			return false;
		}
		http_response_code( 404 ); exit;
	}
}
define( 'ABSPATH', dirname( __DIR__, 4 ) . '/' );
define( 'DB_NAME', $config['database'] );
define( 'DB_USER', $config['user'] );
define( 'DB_PASSWORD', $config['password'] );
define( 'DB_HOST', $config['host'] );
define( 'DB_CHARSET', 'utf8mb4' );
define( 'DB_COLLATE', '' );
$test_secret = hash( 'sha512', (string) getenv( 'ADC_HTTP_TEST_CONFIG' ) . '|wordpress-isolated-http' );
foreach ( array( 'AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT' ) as $secret_name ) {
	define( $secret_name, hash( 'sha512', $test_secret . '|' . $secret_name ) );
}
unset( $test_secret, $secret_name );
define( 'WP_ENVIRONMENT_TYPE', 'local' );
define( 'WP_HTTP_BLOCK_EXTERNAL', true );
define( 'DISABLE_WP_CRON', true );
define( 'WP_DEBUG', false );
if ( str_starts_with( (string) parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/wp-admin/' ) ) { define( 'WP_ADMIN', true ); }
define( 'WP_CONTENT_DIR', __DIR__ . '/isolated-content' );
define( 'WP_CONTENT_URL', $theme_test ? 'http://127.0.0.1:' . (int) $_SERVER['SERVER_PORT'] . '/wp-content' : 'http://adc-verification.invalid/content' );
define( 'WP_PLUGIN_DIR', dirname( __DIR__, 2 ) );
define( 'WP_SITEURL', $theme_test ? 'http://127.0.0.1:' . (int) $_SERVER['SERVER_PORT'] : 'http://adc-verification.invalid' );
define( 'WP_HOME', WP_SITEURL );
define( 'WP_USE_THEMES', $theme_test );
$session_key = hash( 'sha256', (string) getenv( 'ADC_HTTP_TEST_CONFIG' ) . '|session' );
$table_prefix = 'test_';
unset( $config );
if ( '/wp-admin/admin-ajax.php' === (string) parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ) { define( 'DOING_AJAX', true ); }
require ABSPATH . 'wp-settings.php';
add_filter( 'pre_wp_mail', '__return_true' );
if ( $theme_test && '/adc-test-reset-rate' === (string) parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ) {
	if ( ! in_array( $_SERVER['REMOTE_ADDR'] ?? '', array( '127.0.0.1', '::1' ), true ) || ! hash_equals( $session_key, (string) ( $_GET['key'] ?? '' ) ) ) { http_response_code( 403 ); exit; }
	global $wpdb;
	$wpdb->delete( \AutoDealership\Database\Schema::table( 'request_limits' ), array( 'policy_key'=>'intake' ), array( '%s' ) );
	header( 'Content-Type: text/plain' );
	echo 'ok';
	exit;
}
if ( '/adc-test-session' === (string) parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ) {
	if ( ! in_array( $_SERVER['REMOTE_ADDR'] ?? '', array( '127.0.0.1', '::1' ), true ) || ! hash_equals( $session_key, (string) ( $_GET['key'] ?? '' ) ) ) { http_response_code( 403 ); exit; }
	$user_id = absint( $_GET['user_id'] ?? 0 );
	if ( ! get_userdata( $user_id ) ) { http_response_code( 404 ); exit; }
	wp_set_current_user( $user_id );
	wp_set_auth_cookie( $user_id, false, false );
	header( 'Content-Type: application/json' );
	echo wp_json_encode( array( 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
	exit;
}
$request_path = (string) parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH );
if ( '1' === getenv( 'ADC_CURRENCY_BROWSER' ) && '/adc-test-currency' === $request_path ) {
	if ( ! current_user_can( 'manage_options' ) ) { http_response_code( 403 ); exit; }
	require_once ABSPATH . 'wp-admin/includes/template.php';
	$views = array( 'inventory'=>array( \AutoDealership\Admin\OperationsPages::class,'render' ), 'settings'=>array( \AutoDealership\Admin\SettingsPage::class,'render' ), 'payments'=>array( \AutoDealership\Admin\PaymentPages::class,'render' ), 'refunds'=>array( \AutoDealership\Admin\RefundPage::class,'render' ), 'acquisition'=>array( \AutoDealership\Admin\VehicleAcquisitionPage::class,'render' ), 'finance'=>array( \AutoDealership\Admin\WorkflowPages::class,'finance' ) );
	$view = $views[$_GET['view'] ?? ''] ?? null;
	// These fixtures create operational vehicles, independently of the Onyx stock list.
	if ( 'inventory' === ( $_GET['view'] ?? '' ) ) { $_GET['legacy'] = '1'; }
	if ( ! $view ) { http_response_code( 404 ); exit; }
	$lang = \AutoDealership\Core\Localization::language();
	header( 'Content-Type: text/html; charset=utf-8' );
	echo '<!doctype html><html lang="' . esc_attr( $lang ) . '" dir="' . ( 'ar' === $lang ? 'rtl' : 'ltr' ) . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Currency acceptance</title><link rel="stylesheet" href="/wp-content/plugins/auto-dealership-core/assets/css/admin.css"><style>body{margin:24px;font-family:Arial,sans-serif}table{border-collapse:collapse;width:100%}td,th{padding:8px;border:1px solid #ddd}input,select{padding:6px;margin:3px}form{margin-block:16px}</style></head><body>';
	echo '<div class="adc-admin"><div id="wpbody-content">';
	call_user_func( $view );
	echo '</div></div>';
	echo '<script src="/wp-content/plugins/auto-dealership-core/assets/js/admin-layout.js"></script>';
	if ( 'settings' === ( $_GET['view'] ?? '' ) ) { echo '<script src="/wp-content/plugins/auto-dealership-core/assets/js/currency-settings.js"></script>'; }
	echo '</body></html>'; exit;
}
if ( $theme_test && '/adc-test-inventory' === $request_path ) {
	if ( ! in_array( $_SERVER['REMOTE_ADDR'] ?? '', array( '127.0.0.1', '::1' ), true ) || ! hash_equals( $session_key, (string) ( $_GET['key'] ?? '' ) ) ) { http_response_code( 403 ); exit; }
	global $wpdb, $shortcode_tags, $wp_filter;
	$routes = array_keys( rest_get_server()->get_routes() );
	$shortcodes = array();
	foreach ( $shortcode_tags as $tag => $callback ) {
		if ( ! str_starts_with( $tag, 'car_dealer_' ) && ! str_starts_with( $tag, 'ab_' ) ) { continue; }
		$shortcodes[$tag] = is_array( $callback ) && is_string( $callback[0] ) ? $callback[0] . '::' . $callback[1] : ( is_array( $callback ) && is_object( $callback[0] ) ? get_class( $callback[0] ) . '::' . $callback[1] : 'other' );
	}
	$admin_hooks = 0;
	foreach ( $wp_filter['admin_menu']->callbacks ?? array() as $group ) {
		foreach ( $group as $item ) {
			$callback = $item['function'] ?? null;
			if ( is_array( $callback ) && is_string( $callback[0] ) && str_starts_with( $callback[0], 'AutoDealership\\Admin\\' ) ) { ++$admin_hooks; }
		}
	}
	$counts = array();
	foreach ( array( 'vehicles', 'customers', 'leads', 'sales' ) as $name ) { $counts[$name] = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . \AutoDealership\Database\Schema::table( $name ) ); }
	$counts['editorial'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type IN ('car','car_offer')" );
	$data = array(
		'theme' => wp_get_theme()->get_stylesheet(),
		'plugin' => defined( 'ADC_VERSION' ) ? ADC_VERSION : '',
		'post_types' => array_map( 'post_type_exists', array( 'car', 'car_offer', 'cd_crm' ) ),
		'taxonomies' => array_map( 'taxonomy_exists', array( 'car_brand', 'car_category' ) ),
		'shortcodes' => $shortcodes,
		'rest_routes' => array_values( array_filter( $routes, static fn( $route ) => str_starts_with( $route, '/auto-dealership/' ) ) ),
		'privacy_exporter' => false !== has_filter( 'wp_privacy_personal_data_exporters', array( \AutoDealership\Privacy\PrivacyTools::class, 'register_exporter' ) ),
		'privacy_eraser' => false !== has_filter( 'wp_privacy_personal_data_erasers', array( \AutoDealership\Privacy\PrivacyTools::class, 'register_eraser' ) ),
		'ajax_contact_handlers' => isset( $wp_filter['wp_ajax_car_dealer_contact'] ) ? count( $wp_filter['wp_ajax_car_dealer_contact']->callbacks[10] ?? array() ) : 0,
		'ajax_booking_handlers' => isset( $wp_filter['wp_ajax_car_dealer_booking'] ) ? count( $wp_filter['wp_ajax_car_dealer_booking']->callbacks[10] ?? array() ) : 0,
		'anonymous_contact_handlers' => isset( $wp_filter['wp_ajax_nopriv_car_dealer_contact'] ) ? count( $wp_filter['wp_ajax_nopriv_car_dealer_contact']->callbacks[10] ?? array() ) : 0,
		'anonymous_booking_handlers' => isset( $wp_filter['wp_ajax_nopriv_car_dealer_booking'] ) ? count( $wp_filter['wp_ajax_nopriv_car_dealer_booking']->callbacks[10] ?? array() ) : 0,
		'admin_menu_hooks' => $admin_hooks,
		'cron' => array_map( static fn( $hook ) => (bool) wp_next_scheduled( $hook ), array( 'adc_expire_reservations', 'adc_privacy_retention', 'adc_process_outbox', 'adc_prune_request_limits' ) ),
		'administrator_workspace' => (bool) get_role( 'administrator' )?->has_cap( 'adc_view_workspace' ),
		'counts' => $counts,
	);
	header( 'Content-Type: application/json' ); echo wp_json_encode( $data ); exit;
}
if ( $theme_test && '/adc-test-review' === $request_path ) {
	if ( ! current_user_can( 'manage_options' ) ) { http_response_code( 403 ); exit; }
	get_header();
	\AutoDealership\Admin\RequestPage::render( absint( $_GET['lead_id'] ?? 0 ) );
	get_footer(); exit;
}
if ( '/adc-test-nonce' === $request_path ) {
	if ( ! is_user_logged_in() ) { http_response_code( 401 ); exit; }
	$action = sanitize_text_field( wp_unslash( $_GET['action'] ?? '' ) );
	if ( '' === $action ) { http_response_code( 400 ); exit; }
	header( 'Content-Type: text/plain' );
	echo wp_create_nonce( $action );
	exit;
}
if ( '/wp-admin/admin-post.php' === $request_path ) {
	$action = sanitize_key( $_REQUEST['action'] ?? '' );
	if ( '' === $action ) { http_response_code( 400 ); exit; }
	if ( 'adc_export_leads' === $action && '1' === ( $_GET['adc_test_fail_audit'] ?? '' ) ) {
		$audit_table = \AutoDealership\Database\Schema::table( 'audit_events' );
		add_filter( 'query', static function ( string $query ) use ( $audit_table ): string {
			return str_starts_with( $query, 'INSERT INTO `' . $audit_table . '`' ) ? str_replace( '`' . $audit_table . '`', '`missing_adc_test_audit`', $query ) : $query;
		} );
	}
	if ( 'adc_export_leads' === $action && in_array( $_GET['adc_test_fail_export_query'] ?? '', array( 'count', 'page' ), true ) ) {
		$lead_table = \AutoDealership\Database\Schema::table( 'leads' );
		$failure = sanitize_key( $_GET['adc_test_fail_export_query'] );
		add_filter( 'query', static function ( string $query ) use ( $lead_table, $failure ): string {
			$matches = 'count' === $failure
				? str_starts_with( $query, 'SELECT COUNT(*) FROM ' . $lead_table . ' l' )
				: str_starts_with( $query, 'SELECT l.id,l.customer_id,l.branch_id,' ) && str_contains( $query, ' FROM ' . $lead_table . ' l' );
			$replace_count = 0;
			return $matches ? str_replace( $lead_table, 'missing_adc_test_leads', $query, $replace_count ) : $query;
		} );
	}
	do_action( ( is_user_logged_in() ? 'admin_post_' : 'admin_post_nopriv_' ) . $action );
	http_response_code( 400 );
	exit;
}
if ( in_array( $request_path, array( '/wp-admin/admin.php', '/wp-admin/options-general.php' ), true ) ) {
	if ( ! is_user_logged_in() ) { http_response_code( 401 ); exit; }
	require_once ABSPATH . 'wp-admin/includes/admin.php';
	$GLOBALS['pagenow'] = basename( $request_path );
	\AutoDealership\Admin\AdminStructure::redirect();
	$renderers = array( 'adc-sales-journey'=>\AutoDealership\Admin\SalesJourneyPage::class, 'adc-customer-workspace'=>\AutoDealership\Admin\CustomerWorkspacePage::class, 'adc-follow-ups'=>\AutoDealership\Admin\FollowUpPage::class, 'adc-purchase-orders'=>\AutoDealership\Admin\PurchaseOrderPage::class, 'adc-release-evidence'=>\AutoDealership\Admin\ReleaseEvidencePage::class );
	$page = sanitize_key( $_GET['page'] ?? '' );
	$workspace_renderers = array(
		'adc-workspace'=>array( \AutoDealership\Admin\WorkspacePage::class, 'render' ),
		'adc-onyx-documents'=>array( \AutoDealership\Sales\OnyxDocuments::class, 'render' ),
		'adc-profit-margin'=>array( \AutoDealership\Admin\ProfitMarginPage::class, 'render' ),
		'adc-approvals'=>array( \AutoDealership\Admin\WorkflowPages::class, 'approvals' ),
		'adc-finance'=>array( \AutoDealership\Admin\WorkflowPages::class, 'finance' ),
		'adc-payments'=>array( \AutoDealership\Admin\PaymentPages::class, 'render' ),
		'adc-platform-setup'=>array( \AutoDealership\Core\ProductSetup::class, 'render' ),
		'adc-contact'=>array( \AutoDealership\Core\ProductSetup::class, 'render_contact' ),
		'adc-social-channels'=>array( \AutoDealership\Core\SocialChannels::class, 'admin' ),
		'adc-portal-operations'=>array( \AutoDealership\Portal\PortalOperations::class, 'render' ),
		'adc-branch-locations'=>array( \AutoDealership\Core\BranchLocations::class, 'admin' ),
		'adc-editorial-setup'=>array( \AutoDealership\Admin\EditorialSetupPage::class, 'render' ),
		'adc-vehicle-acquisition'=>array( \AutoDealership\Admin\VehicleAcquisitionPage::class, 'render' ),
		'adc-transfers'=>array( \AutoDealership\Admin\TransferPages::class, 'render' ),
		'adc-site-content'=>array( \AutoDealership\Admin\SiteContentPage::class, 'render' ),
	);
	if ( str_starts_with( $page, 'adc-area-' ) ) { \AutoDealership\Admin\WorkspacePage::render(); exit; }
	if ( isset( $workspace_renderers[$page] ) ) { call_user_func( $workspace_renderers[$page] ); exit; }
	if ( ! isset( $renderers[$page] ) ) { http_response_code( 404 ); exit; }
	$renderers[$page]::render(); exit;
}
if ( '/wp-admin/admin-ajax.php' === $request_path ) {
	$action = sanitize_key( $_REQUEST['action'] ?? '' );
	if ( ! in_array( $action, array( 'car_dealer_contact', 'car_dealer_booking', 'car_dealer_lead', 'car_dealer_subscribe', 'car_dealer_comparison', 'car_dealer_loan_calculator', 'adc_lookup_vin', 'adc_move_lead_stage', 'adc_portal_poll', 'adc_live_chat', 'adc_live_status', 'adc_chat_availability', 'adc_newsletter_preview', 'adc_jobs_tick', 'adc_jobs_probe' ), true ) ) { http_response_code( 400 ); exit; }
	do_action( ( is_user_logged_in() ? 'wp_ajax_' : 'wp_ajax_nopriv_' ) . $action );
	http_response_code( 400 ); exit;
}
wp();
require ABSPATH . WPINC . '/template-loader.php';
