'use strict';
// Read-only public-site acceptance against the local development origin.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

(async () => {
    const origin = process.env.ADC_SITE_ORIGIN || 'http://localhost/wordpress';
    assert.match(origin, /^http:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?\/wordpress\/?$/);
    const root = origin.replace(/\/$/, '');
    const profileRoot = path.resolve(__dirname, '../../../../.tmp/browser-profiles');
    fs.mkdirSync(profileRoot, { recursive: true });
    const profile = fs.mkdtempSync(path.join(profileRoot, 'adc-bilingual-'));
    const browser = spawn(process.env.ADC_BROWSER || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
        '--headless=new', '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0',
        '--no-first-run', '--disable-background-networking', '--disable-sync',
        `--user-data-dir=${profile}`, 'about:blank'
    ], { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] });
    let browserLog = '';
    browser.stderr.on('data', chunk => { browserLog = (browserLog + chunk.toString()).slice(-2000); });
    const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
    let socket;
    let passed = 0;
    const errors = [];
    const badAssets = [];
    const captures = path.resolve(__dirname, '../../../../.tmp/bilingual-acceptance');
    fs.mkdirSync(captures, { recursive: true });
    const check = (value, description) => {
        assert.ok(value, description);
        passed++;
        process.stdout.write(`PASS ${description}\n`);
    };
    try {
        const activePort = path.join(profile, 'DevToolsActivePort');
        for (let i = 0; i < 200 && !fs.existsSync(activePort); i++) await pause(100);
        assert.ok(fs.existsSync(activePort), `Browser must start: ${browserLog}`);
        const port = Number(fs.readFileSync(activePort, 'utf8').split('\n')[0]);
        const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
        const target = targets.find(item => item.type === 'page');
        assert.ok(target, 'Browser page target must exist');
        socket = new WebSocket(target.webSocketDebuggerUrl);
        await new Promise((resolve, reject) => { socket.onopen = resolve; socket.onerror = reject; });
        let sequence = 0;
        const pending = new Map();
        const call = (method, params = {}) => new Promise((resolve, reject) => {
            const id = ++sequence;
            const timer = setTimeout(() => { pending.delete(id); reject(new Error(`CDP timeout: ${method}`)); }, 15000);
            pending.set(id, { resolve, reject, timer });
            socket.send(JSON.stringify({ id, method, params }));
        });
        socket.onmessage = event => {
            const data = JSON.parse(event.data);
            if (data.method === 'Runtime.exceptionThrown') errors.push(data.params.exceptionDetails.text);
            if (data.method === 'Network.responseReceived' && data.params.response.status >= 400 && ['Stylesheet', 'Script'].includes(data.params.type)) badAssets.push(data.params.response.url);
            if (data.method === 'Fetch.requestPaused') {
                const request = data.params;
                const local = request.request.url.startsWith(root + '/') || request.request.url.startsWith('data:');
                call(local ? 'Fetch.continueRequest' : 'Fetch.failRequest', local ? { requestId: request.requestId } : { requestId: request.requestId, errorReason: 'BlockedByClient' }).catch(() => {});
            }
            const waiting = pending.get(data.id);
            if (!waiting) return;
            clearTimeout(waiting.timer);
            pending.delete(data.id);
            data.error ? waiting.reject(new Error(data.error.message)) : waiting.resolve(data.result);
        };
        await call('Page.enable');
        await call('Runtime.enable');
        await call('Network.enable');
        await call('Fetch.enable', { patterns: [{ urlPattern: '*' }] });
        const evaluate = async expression => {
            const response = await call('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
            if (response.exceptionDetails) throw new Error(JSON.stringify(response.exceptionDetails));
            return response.result.value;
        };
        const wait = async (expression, description) => {
            for (let i = 0; i < 120; i++) {
                try { if (await evaluate(expression)) return; } catch {}
                await pause(100);
            }
            throw new Error(`Timed out: ${description}; URL: ${await evaluate('location.href')}`);
        };
        const visit = async route => {
            const marker = String(Date.now()) + Math.random();
            await evaluate('window.__navigationMarker=' + JSON.stringify(marker));
            await call('Page.navigate', { url: root + route });
            await wait("window.__navigationMarker !== " + JSON.stringify(marker) + " && document.readyState === 'complete' && !!document.querySelector('#colophon')", route);
        };
        const state = () => evaluate(`(() => {
            const switches = [...document.querySelectorAll('.site-language-switch')];
            const wa = document.querySelector('.ab-float-wa');
            return {
                language: document.documentElement.lang, direction: document.documentElement.dir,
                switches: switches.length,
                active: switches.map(x => x.querySelector('[aria-current="page"]')?.getAttribute('lang')),
                links: switches[0] ? [...switches[0].querySelectorAll('a')].map(x => ({lang:x.lang,url:x.href})) : [],
                whatsapp: wa?.href || '', waPosition: wa ? getComputedStyle(wa).position : '',
                footer: !!document.querySelector('#colophon .footer-grid'),
                legalLinks: [...document.querySelectorAll('#colophon .footer-legal-links a')].map(x => x.href),
                overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
                body: document.body.innerText
            };
        })()`);
        if (process.env.ADC_TYPOGRAPHY_ONLY === '1') {
            await visit('/wp-content/plugins/auto-dealership-core/tests/fixtures/typography.html');
            check(await evaluate("(async()=>{for(const weight of [200,300,400,500,700,800,900]){const faces=await document.fonts.load(`${weight} 16px Tajawal`,'أوتو براندز Auto Brands');if(!faces.length||faces.some(x=>x.status!=='loaded'))return false;}return true;})()"), 'All seven real local Tajawal font files load');
            check(await evaluate("[document.body,...document.querySelectorAll('h1,p,label,input,textarea,select,button,th,td,.ab-label,.select2-selection,.ui-widget,.editor-styles-wrapper')].every(x=>getComputedStyle(x).fontFamily.includes('Tajawal'))"), 'WordPress admin, editor, Meta Box, forms and public text use Tajawal');
            check(await evaluate("getComputedStyle(document.querySelector('.dashicons')).fontFamily.includes('dashicons') && getComputedStyle(document.querySelector('.ab-icon'),'::before').fontFamily.includes('dashicons')"), 'Dashicons and admin-bar icon pseudo-elements are preserved');
            await call('Emulation.setEmulatedMedia', { media: 'print' });
            check(await evaluate("getComputedStyle(document.body).fontFamily.includes('Tajawal') && document.fonts.check('700 16px Tajawal')"), 'Print media retains locally loaded Tajawal');
        check(errors.length === 0 && badAssets.length === 0, 'Typography fixture has no browser exceptions or missing assets');
            process.stdout.write(`TAJAWAL PASS: ${passed} fixture checks.\n`);
            return;
        }
        await visit('/');
        let page = await state();
        check(page.language === 'ar' && page.direction === 'rtl', 'Arabic home declares RTL');
        const arabicBrandIsLocalized = `(() => {
            const pattern = /AUTO\\s+BRANDS/i;
            if (pattern.test(document.title) || pattern.test(document.body.innerText)) return false;
            if ([...document.querySelectorAll('[alt],[title],[aria-label],[placeholder]')].some(node => ['alt','title','aria-label','placeholder'].some(name => pattern.test(node.getAttribute(name) || '')))) return false;
            if ([...document.querySelectorAll('script[type="application/ld+json"]')].some(node => pattern.test(node.textContent || ''))) return false;
            return [...document.querySelectorAll('a[href*="wa.me"]')].every(link => { try { return !pattern.test(new URL(link.href).searchParams.get('text') || ''); } catch { return true; } });
        })()`;
        check(await evaluate(arabicBrandIsLocalized), 'Arabic home localizes the brand name in visible and accessible copy');
        await call('Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9 });
        await call('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9 });
        check(await evaluate("document.activeElement?.classList.contains('skip-link') && getComputedStyle(document.activeElement).clip === 'auto'"), 'Keyboard entry focuses the visible skip-to-content link');
        check(page.switches >= 1 && page.active.every(x => x === 'ar') && await evaluate("!!document.querySelector('.site-header .site-language-switch')"), 'Header language switch exists and every rendered switch marks Arabic active');
        check(page.whatsapp.includes('wa.me/966550928190') && page.waPosition === 'fixed', 'Configured WhatsApp button is fixed and visible');
        check(page.footer && page.legalLinks.length >= 2, 'Footer exposes the published legal pages');
        for (const legalUrl of page.legalLinks) {
            const response = await fetch(legalUrl);
            check(response.status === 200 && !(await response.text()).includes('wp-die-message'), 'Published legal link is accessible: ' + new URL(legalUrl).pathname);
        }
        check(await evaluate("document.querySelectorAll('.car-image-placeholder svg').length > 0 && !document.querySelector('.car-image-placeholder')?.textContent.includes('🚘')"), 'Vehicles without photos use a vector placeholder');
        await call('Emulation.setDeviceMetricsOverride', { width: 1440, height: 900, deviceScaleFactor: 1, mobile: false });
        await visit('/?lang=en');
        page = await state();
        check(page.language === 'en' && page.direction === 'ltr', 'English home declares LTR');
        check(page.active.every(x => x === 'en') && page.body.includes('Your new vehicle starts with Auto Brands'), 'English switch and home copy render');
        check(await evaluate("(() => {const f=document.querySelector('#colophon .cd-newsletter-form');return !!f && getComputedStyle(f).backgroundColor === 'rgba(0, 0, 0, 0)' && getComputedStyle(f.querySelector('label')).color === 'rgb(255, 255, 255)' && getComputedStyle(f.querySelector('.cd-newsletter-consent')).flexDirection === 'row';})()"), 'Footer newsletter has readable text and aligned consent');
        check(await evaluate(`(() => {
            const footer = document.querySelector('.site-footer');
            const css = getComputedStyle(footer);
            const stops = [...(css.backgroundImage === 'none' ? css.backgroundColor : css.backgroundImage).matchAll(/rgba?\\(([^)]+)\\)/g)].map(match => match[1].split(',').slice(0, 3).map(Number));
            const foreground = [255, 255, 255];
            const luminance = color => color.map(value => {const c = value / 255; return c <= .04045 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4;}).reduce((sum, value, i) => sum + value * [.2126, .7152, .0722][i], 0);
            return stops.length >= 1 && stops.every(stop => (luminance(foreground) + .05) / (luminance(stop) + .05) >= 4.5);
        })()`), 'White footer form labels meet 4.5:1 against the current footer background');
        check(page.links.find(x => x.lang === 'ar')?.url.endsWith('/wordpress/'), 'Arabic switch returns to the home view');
        fs.writeFileSync(path.join(captures, 'home-en-desktop.png'), Buffer.from((await call('Page.captureScreenshot', { format: 'png' })).data, 'base64'));
        await evaluate("document.documentElement.style.scrollBehavior='auto';window.scrollTo(0,document.documentElement.scrollHeight)");
        await pause(100);
        fs.writeFileSync(path.join(captures, 'footer-en-desktop.png'), Buffer.from((await call('Page.captureScreenshot', { format: 'png' })).data, 'base64'));
        check(await evaluate("[...document.querySelectorAll('#site-navigation a')].filter(a => a.href.startsWith(location.origin + '/wordpress/')).every(a => new URL(a.href).searchParams.get('lang') === 'en')"), 'Primary internal navigation keeps English');
        check(await evaluate("document.querySelector('.header-search input[name=lang]')?.value === 'en' && new URL(document.querySelector('.header-search').action).pathname.endsWith('/cars/') && !!document.querySelector('.header-search input[name=search]')"), 'Vehicle search form targets the catalog and preserves English');
        await evaluate("(() => {const f=document.querySelector('.header-search');f.elements.search.value='Synthetic';f.requestSubmit();})()");
        await wait("document.readyState === 'complete' && location.pathname.endsWith('/cars/') && new URL(location.href).searchParams.get('search') === 'Synthetic' && new URL(location.href).searchParams.get('lang') === 'en'", 'English vehicle search');
        check(true, 'Submitting vehicle search keeps the query and English');
        for (const [route, expected] of [
            ['/about/?lang=en', 'About us'], ['/contact/?lang=en', 'Contact us'],
            ['/faq/?lang=en', 'FAQ'], ['/buying-guide/?lang=en', 'Your vehicle buying guide'],
            ['/finance/?lang=en', 'Finance Calculator'], ['/cars/?lang=en', 'Browse AUTO BRANDS Vehicles'],
            ['/offers/?lang=en', 'AUTO BRANDS Offers'], ['/?cd_account=login&lang=en', 'Welcome back']
        ]) {
            await visit(route);
            page = await state();
            check(page.language === 'en' && page.direction === 'ltr' && page.body.includes(expected), `${route} renders English`);
            const arabicLink = page.links.find(x => x.lang === 'ar')?.url;
            check(arabicLink && new URL(arabicLink).pathname === new URL(root + route).pathname && !arabicLink.includes('lang=en'), `${route} keeps its path in the Arabic switch`);
            check(!page.body.includes('Warning:') && !page.body.includes('Fatal error'), `${route} has no visible PHP warning`);
        }
        await visit('/?cd_account=register&lang=en');
        check((await state()).body.includes('Create account') && await evaluate("document.querySelector('.cd-auth-form form')?.action.includes('lang=en')"), 'English registration form preserves language');
        check(await evaluate(`(() => {
            const control = document.querySelector('[data-auth-view="register"] [name="privacy_consent"]');
            control.checked = false;
            const valid = control.reportValidity();
            const localized = control.validationMessage === 'You must agree to the Privacy Policy and Terms of Use to create an account.';
            const error = document.getElementById(control.id + '-validation');
            const label = control.closest('label');
            const gap = error.getBoundingClientRect().top - label.getBoundingClientRect().bottom;
            const inline = error?.textContent === control.validationMessage && getComputedStyle(error).display === 'block' && gap >= 0 && gap <= 8;
            control.checked = true;
            control.dispatchEvent(new Event('change', {bubbles:true}));
            return !valid && localized && inline && control.validationMessage === '' && !document.getElementById(control.id + '-validation');
        })()`), 'English required consent uses localized browser and inline validation, then clears after correction');
        check(await evaluate(`(() => {
            const control = document.querySelector('[data-auth-view="register"] [name="email"]');
            control.value = 'invalid-address';
            control.dispatchEvent(new Event('input', {bubbles:true}));
            const valid = control.reportValidity();
            const localized = control.validationMessage === 'Please enter a valid email address.';
            control.value = 'reader@example.com';
            control.dispatchEvent(new Event('input', {bubbles:true}));
            return !valid && localized && control.validationMessage === '';
        })()`), 'English email validation is localized and does not remain stale');
        check(await evaluate(`(() => {
            const form = document.querySelector('[data-auth-view="register"]');
            const panel = form.querySelector('[data-password-policy-panel]');
            const password = form.elements.password;
            password.value = 'abcdefghij1!';
            password.dispatchEvent(new Event('input', {bubbles:true}));
            const rejected = !password.reportValidity() && password.validationMessage === 'Please meet all password requirements.';
            const rules = [...panel.querySelectorAll('[data-password-rule]')];
            const uppercase = panel.querySelector('[data-password-rule="uppercase"]');
            return rejected && panel.innerText.includes('Password requirements') && rules.length === 6 && rules.filter(rule => rule.classList.contains('is-met')).length === 5 && !uppercase.classList.contains('is-met') && getComputedStyle(panel.querySelector('[data-password-copy]')).display === 'none';
        })()`), 'English password policy visibly requires an uppercase English letter');
        check(await evaluate(`(() => {
            const form = document.querySelector('[data-auth-view="register"]');
            const password = form.elements.password;
            const confirmation = form.elements.password_confirm;
            password.value = 'Abcdefghij1!';
            confirmation.value = 'Abcdefghij2!';
            password.dispatchEvent(new Event('input', {bubbles:true}));
            confirmation.dispatchEvent(new Event('input', {bubbles:true}));
            const rejected = !confirmation.reportValidity() && confirmation.validationMessage === 'The password confirmation does not match.';
            confirmation.value = password.value;
            confirmation.dispatchEvent(new Event('input', {bubbles:true}));
            return rejected && confirmation.validationMessage === '' && form.querySelector('[data-password-confirm-status]').textContent === 'Passwords match.';
        })()`), 'English password confirmation is enforced and updates live');
        check(await evaluate(`(() => {
            const form = document.querySelector('[data-auth-view="register"]');
            form.querySelector('[data-password-generate]').click();
            const password = form.elements.password.value;
            const confirmation = form.elements.password_confirm.value;
            const panel = form.querySelector('[data-password-policy-panel]');
            return password.length === 20 && password === confirmation && /^[\x21-\x7E]+$/.test(password) && /[A-Z]/.test(password) && /[a-z]/.test(password) && /[0-9]/.test(password) && /[^A-Za-z0-9]/.test(password) && panel.querySelectorAll('[data-password-rule].is-met').length === 6 && panel.querySelector('[data-password-meter]').dataset.level === '4' && getComputedStyle(panel.querySelector('[data-password-copy]')).display !== 'none' && panel.querySelector('[data-password-status]').textContent.includes('generated and confirmed');
        })()`), 'Secure generator creates and confirms a very strong English password');
        check(await evaluate(`(() => {
            const form = document.querySelector('[data-auth-view="register"]');
            const data = new URLSearchParams(new FormData(form));
            data.set('display_name', 'Policy verification');
            data.set('email', 'password-policy@example.invalid');
            data.set('phone', '+966500000001');
            data.set('password', 'abcdefghij1!');
            data.set('password_confirm', 'abcdefghij1!');
            data.set('privacy_consent', '1');
            return fetch(form.action, {method:'POST', credentials:'same-origin', body:data}).then(response => response.text()).then(html => html.includes('Use 12 to 128 characters made up of English letters, numbers, and symbols. Include an uppercase letter, a lowercase letter, a number, and a symbol, with no spaces.'));
        })()`), 'Server rejects a password without an uppercase letter when browser validation is bypassed');
        await visit('/?cd_account=register');
        check(await evaluate(`(() => {
            const control = document.querySelector('[data-auth-view="register"] [name="privacy_consent"]');
            control.checked = false;
            const valid = control.reportValidity();
            const localized = control.validationMessage === 'يجب الموافقة على سياسة الخصوصية وشروط الاستخدام لإنشاء الحساب.';
            const error = document.getElementById(control.id + '-validation');
            const label = control.closest('label');
            const gap = error.getBoundingClientRect().top - label.getBoundingClientRect().bottom;
            const inline = error?.textContent === control.validationMessage && getComputedStyle(error).display === 'block' && gap >= 0 && gap <= 8;
            control.checked = true;
            control.dispatchEvent(new Event('change', {bubbles:true}));
            return !valid && localized && inline && control.validationMessage === '' && !document.getElementById(control.id + '-validation');
        })()`), 'Arabic required consent uses localized browser and inline validation, then clears after correction');
        check(await evaluate(`(() => {
            const form = document.querySelector('[data-auth-view="register"]');
            const panel = form.querySelector('[data-password-policy-panel]');
            const password = form.elements.password;
            password.value = 'كلمةمرورطويلة!';
            password.dispatchEvent(new Event('input', {bubbles:true}));
            const rejected = !password.reportValidity() && password.validationMessage === 'تأكد من استيفاء جميع شروط كلمة المرور.';
            const asciiRule = panel.querySelector('[data-password-rule="ascii"]');
            const rejectedArabic = !asciiRule.classList.contains('is-met');
            panel.querySelector('[data-password-generate]').click();
            return rejected && rejectedArabic && panel.innerText.includes('حرف إنجليزي كبير') && panel.innerText.includes('أحرف إنجليزية وأرقام ورموز فقط') && form.elements.password.value === form.elements.password_confirm.value && /^[\x21-\x7E]+$/.test(form.elements.password.value) && panel.querySelectorAll('[data-password-rule].is-met').length === 6 && panel.querySelector('[data-password-strength-label]').textContent === 'قوية جدًا';
        })()`), 'Arabic interface rejects Arabic password characters and the secure generator meets every rule');
        check(await evaluate(`(() => {
            const form = document.querySelector('[data-auth-view="register"]');
            const data = new URLSearchParams(new FormData(form));
            data.set('display_name', 'اختبار سياسة كلمة المرور');
            data.set('email', 'arabic-password-policy@example.invalid');
            data.set('phone', '+966500000002');
            data.set('password', 'Abcdef1!كلمة');
            data.set('password_confirm', 'Abcdef1!كلمة');
            data.set('privacy_consent', '1');
            return fetch(form.action, {method:'POST', credentials:'same-origin', body:data}).then(response => response.text()).then(html => html.includes('استخدم من 12 إلى 128 محرفًا من الأحرف الإنجليزية والأرقام والرموز. يجب تضمين حرف إنجليزي كبير وحرف إنجليزي صغير ورقم ورمز خاص، دون مسافات.'));
        })()`), 'Server rejects Arabic password characters even when every other requirement is met');
        for (const [route, expected] of [['/about/', 'من نحن'], ['/contact/', 'تواصل معنا'], ['/finance/', 'حاسبة التمويل'], ['/faq/', 'الأسئلة الشائعة'], ['/buying-guide/', 'دليلك لاختيار السيارة'], ['/cars/', 'استعرض سيارات أوتو براندز'], ['/offers/', 'اكتشف عروض أوتو براندز'], ['/?cd_account=login', 'أهلاً بك في أوتو براندز']]) {
            await visit(route);
            page = await state();
            check(page.language === 'ar' && page.direction === 'rtl' && page.body.includes(expected), `${route} renders Arabic`);
            check(await evaluate(arabicBrandIsLocalized), `${route} localizes the brand name throughout the Arabic page`);
        }
        await visit('/finance/');
        check(await evaluate("document.querySelector('.entry-content').innerText.includes('النتيجة إرشادية وغير ملزمة') && !document.querySelector('.entry-content').innerText.includes('Explore how the down payment')"), 'Finance page shows only Arabic editorial content');
        await visit('/contact/?lang=en');
        check(await evaluate("document.querySelector('.cd-contact-form [name=lang]')?.value === 'en' && document.querySelector('.cd-contact-form button')?.textContent.trim() === 'Send'"), 'English contact form preserves language without submission');
        await visit('/?lang=en');
        check(await evaluate("(() => {const f=document.querySelector('.cd-newsletter-form'); return f?.querySelector('[name=lang]')?.value === 'en' && f.innerText.includes('I agree to receive marketing messages') && f.querySelector('[name=consent_marketing]')?.required;})()"), 'English newsletter includes language and explicit consent');
        check(await evaluate(`fetch(window.adcPublicIntake.ajaxUrl, {method:'POST', credentials:'same-origin', body:new URLSearchParams({action:'car_dealer_subscribe', nonce:window.adcPublicIntake.nonce, lang:'en', email:'invalid', consent_marketing:'0'})}).then(response=>response.json()).then(result=>result.success===false && result.data.message==='Enter a valid email address and explicitly agree to subscribe.')`), 'English newsletter validation response is localized without saving a subscriber');
        await evaluate("(() => {const f=document.querySelector('.cd-newsletter-form');f.querySelector('[name=email]').value='reader@example.invalid';f.querySelector('[name=consent_marketing]').checked=true;window.fetch=()=>Promise.reject(new Error('offline fixture'));f.requestSubmit();})()");
        await wait("document.querySelector('.cd-newsletter-form .cd-form-status')?.textContent === 'The request could not be sent right now.'", 'English newsletter network error');
        check(true, 'English newsletter network error is localized without a server write');
        await visit('/');
        check(await evaluate("(() => {const f=document.querySelector('.cd-newsletter-form');return f?.querySelector('[name=lang]')?.value === 'ar' && f.innerText.includes('أوافق على استلام رسائل') && f.querySelector('[name=consent_marketing]')?.required;})()"), 'Arabic newsletter includes language and explicit consent');
        check(await evaluate(`fetch(window.adcPublicIntake.ajaxUrl, {method:'POST', credentials:'same-origin', body:new URLSearchParams({action:'car_dealer_subscribe', nonce:window.adcPublicIntake.nonce, lang:'ar', email:'invalid', consent_marketing:'0'})}).then(response=>response.json()).then(result=>result.success===false && result.data.message.includes('أدخل بريدًا صحيحًا'))`), 'Arabic newsletter validation response is localized without saving a subscriber');
        await visit('/missing-page-for-404-review/?lang=en');
        check(await evaluate("document.querySelector('.cd-not-found h1')?.textContent === 'Page not found' && document.querySelector('.cd-not-found-search [name=lang]')?.value === 'en'"), 'English 404 has a translated search and recovery path');
        check(await evaluate("fetch(location.href).then(response => response.status === 404)"), 'Missing page responds with HTTP 404');
        await call('Accessibility.enable');
        const accessibility = (await call('Accessibility.getFullAXTree')).nodes;
        check(accessibility.some(node => node.role?.value === 'heading' && node.name?.value === 'Page not found') && accessibility.some(node => node.role?.value === 'search'), '404 exposes a named heading and search landmark to accessibility APIs');
        await visit('/missing-page-for-404-review/');
        check(await evaluate("document.querySelector('.cd-not-found h1')?.textContent === 'الصفحة غير موجودة'"), 'Arabic 404 heading is localized');
        await visit('/faq/?lang=en');
        check(await evaluate("(() => {const t=document.querySelector('.entry-content').innerText;return t.includes('20000.00 SAR') && t.includes('24 hours') && t.includes('72 hours') && t.includes('recorded financial verification');})()"), 'English FAQ presents the currently published reservation and refund policy');
        await visit('/about/');
        check(await evaluate("(() => {const t=document.querySelector('.entry-content').innerText;return t.includes('تحت الإنشاء') && t.includes('20000.00') && t.includes('72 ساعة') && t.includes('التحقق المالي');})()"), 'Arabic about copy includes construction status and the current refund policy');
        await visit('/contact/?lang=en');
        check(await evaluate("document.querySelector('a[href=\"mailto:autobrands2020@gmail.com\"]') && [...document.querySelectorAll('a[href^=\"tel:\"]')].some(a=>/^(966|0)550928190$/.test(a.href.replace(/[^0-9]/g,''))) && document.querySelector('.entry-content').innerText.includes('main branch')"), 'English contact exposes the configured email, callable phone and branch guidance');
        await visit('/cars/');
        check(await evaluate("document.querySelectorAll('.car-card').length > 0 && [...document.querySelectorAll('.car-image-placeholder')].every(x=>/صورة/.test(x.textContent))"), 'Published inventory renders and fallback images have an Arabic explanation');
        check(await evaluate("document.querySelector('#site-navigation a[href*=\"/faq/\"]') && document.querySelector('#site-navigation a[href*=\"/buying-guide/\"]')"), 'Primary navigation exposes FAQ and buying-guide pages');
        const detailUrl = new URL(await evaluate("document.querySelector('.car-card a')?.href"));
        detailUrl.searchParams.set('lang', 'en');
        await visit(detailUrl.href.slice(root.length));
        check(await evaluate("document.documentElement.lang === 'en' && document.documentElement.dir === 'ltr' && !!document.querySelector('h1')?.innerText.trim()"), 'A current published vehicle has an English LTR detail page');
        const detailArabic = (await state()).links.find(x => x.lang === 'ar')?.url;
        check(detailArabic && new URL(detailArabic).pathname === detailUrl.pathname, 'Vehicle language switch preserves the selected vehicle');
        await visit(detailArabic.slice(root.length));
        check(await evaluate("document.documentElement.lang === 'ar' && document.documentElement.dir === 'rtl' && !!document.querySelector('h1')?.innerText.trim()"), 'The same published vehicle has an Arabic RTL detail page');
        await visit('/finance/?lang=en');
        check(await evaluate("document.querySelector('.entry-content').innerText.includes('Explore how the down payment') && !document.querySelector('.entry-content').innerText.includes('النتيجة إرشادية وغير ملزمة')"), 'Finance page shows only English editorial content');
        for (const width of [1440, 768, 390, 320]) {
            await call('Emulation.setDeviceMetricsOverride', { width, height: 900, deviceScaleFactor: 1, mobile: width <= 390 });
            await pause(150);
            page = await state();
            check(page.overflow <= 2, `English layout has no page overflow at ${width}px`);
            check(await evaluate("(() => {const a=document.querySelector('.site-header .site-language-switch');const r=a.getBoundingClientRect();return r.width>0&&r.left>=0&&r.right<=innerWidth;})()"), `Language control remains in viewport at ${width}px`);
            if (width === 390) {
                await visit('/contact/?lang=en');
                fs.writeFileSync(path.join(captures, 'contact-en-mobile.png'), Buffer.from((await call('Page.captureScreenshot', { format: 'png' })).data, 'base64'));
                await evaluate("document.documentElement.style.scrollBehavior='auto';window.scrollTo(0,document.documentElement.scrollHeight)");
                await pause(100);
                check(await evaluate("(() => {const a=document.querySelector('.ab-float-wa').getBoundingClientRect();const c=document.querySelector('.footer-copyright').getBoundingClientRect();return a.bottom<=innerHeight && (a.left>=c.right || a.top>=c.bottom || a.right<=c.left);})()"), 'Floating WhatsApp does not cover mobile footer copyright');
                fs.writeFileSync(path.join(captures, 'footer-en-mobile.png'), Buffer.from((await call('Page.captureScreenshot', { format: 'png' })).data, 'base64'));
                await visit('/finance/?lang=en');
            }
        }
        await visit('/contact/');
        for (const width of [390, 320]) {
            await call('Emulation.setDeviceMetricsOverride', { width, height: 900, deviceScaleFactor: 1, mobile: true });
            await pause(120);
            page = await state();
            check(page.language === 'ar' && page.direction === 'rtl' && page.overflow <= 2, `Arabic contact fits RTL viewport ${width}px`);
            check(await evaluate("(() => {const a=document.querySelector('.site-header .site-language-switch').getBoundingClientRect();return a.width>0&&a.left>=0&&a.right<=innerWidth;})()"), `Arabic language control remains visible at ${width}px`);
            if (width === 390) {
                await evaluate("document.documentElement.style.scrollBehavior='auto';window.scrollTo(0,document.documentElement.scrollHeight)");
                await pause(100);
                fs.writeFileSync(path.join(captures, 'footer-ar-mobile.png'), Buffer.from((await call('Page.captureScreenshot', { format: 'png' })).data, 'base64'));
            }
        }
        await visit('/contact/');
        check(await evaluate("(async()=>{for(const weight of [200,300,400,500,700,800,900]){const faces=await document.fonts.load(`${weight} 16px Tajawal`, 'أوتو براندز Auto Brands');if(!faces.length||faces.some(face=>face.status!=='loaded'))return false;}return true;})()"), 'All seven local Tajawal weights load successfully');
        check(await evaluate("[document.body,...document.querySelectorAll('h1,h2,p,input,textarea,button')].every(el=>getComputedStyle(el).fontFamily.includes('Tajawal'))"), 'Public text and form controls use Tajawal');
        // Cookie UI is created by JavaScript after page load, outside PHP gettext.
        for (const language of ['en', 'ar']) {
            await evaluate("localStorage.removeItem('cd_cookie_consent')");
            await visit(language === 'en' ? '/contact/?lang=en' : '/contact/');
            await wait("!!document.querySelector('#cd-cookie-banner')", `${language} cookie banner`);
            check(await evaluate(`(() => {const banner=document.querySelector('#cd-cookie-banner');return banner.lang==='${language}' && banner.dir==='${language === 'en' ? 'ltr' : 'rtl'}' && banner.innerText.includes('${language === 'en' ? 'Essential only' : 'الأساسية فقط'}');})()`), `${language} cookie banner follows selected language and direction`);
            await evaluate("document.querySelector('#cd-cookie-settings-btn').click()");
            check(await evaluate(`(() => {const modal=document.querySelector('#cd-cookie-settings');return modal.lang==='${language}' && modal.innerText.includes('${language === 'en' ? 'Analytics' : 'تحليلات'}') && modal.innerText.includes('${language === 'en' ? 'Save preferences' : 'حفظ التفضيلات'}') && ${language === 'en' ? '!/[\\u0600-\\u06ff]/u.test(modal.innerText)' : 'modal.dir === "rtl"'};})()`), `${language} cookie settings and categories have localized copy`);
        }
        await call('Page.navigate', { url: root + '/wp-login.php' });
        await wait("document.readyState==='complete' && !!document.querySelector('#loginform')", 'WordPress login typography');
        check(await evaluate("(async()=>{await document.fonts.load('400 16px Tajawal','دخول Login');return document.fonts.check('400 16px Tajawal') && [document.body,...document.querySelectorAll('#login input,#login label,#login button')].every(el=>getComputedStyle(el).fontFamily.includes('Tajawal'));})()"), 'WordPress login and controls use locally loaded Tajawal');
        check(await evaluate("[...document.querySelectorAll('.dashicons')].every(el=>getComputedStyle(el).fontFamily.includes('dashicons'))"), 'Login icon glyphs retain Dashicons');
        check(errors.length === 0, `No browser runtime exceptions: ${errors.join('; ')}`);
        check(badAssets.length === 0, `No missing local scripts or styles: ${badAssets.join('; ')}`);
        process.stdout.write(`BILINGUAL SITE PASS: ${passed} checks; screenshots: ${captures}\n`);
    } finally {
        if (socket) socket.close();
        browser.kill();
        await pause(500);
        if (path.dirname(path.resolve(profile)) === profileRoot && path.basename(profile).startsWith('adc-bilingual-')) {
            try { fs.rmSync(profile, { recursive: true, force: true }); } catch {}
        }
    }
})().catch(error => { process.stderr.write(`${error.stack || error}\n`); process.exitCode = 1; });
