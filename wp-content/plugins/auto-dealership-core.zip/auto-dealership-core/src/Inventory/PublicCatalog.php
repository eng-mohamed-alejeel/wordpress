<?php
namespace AutoDealership\Inventory;

use AutoDealership\Database\Schema;

defined( 'ABSPATH' ) || exit;

/** Public read model and gradual cutover boundary for operational inventory. */
final class PublicCatalog {
	public const MODE_COMPATIBILITY = 'compatibility';
	public const MODE_AUTHORITATIVE = 'authoritative';
	public const MODE_MODELS = 'models';
	public const OPTION_MODE = 'adc_public_catalog_mode';

	private const TEXT_FILTERS = array(
		'brand'          => 'brand',
		'model'          => 'model',
		'trim'           => 'trim_name',
		'body_type'      => 'body_type',
		'fuel_type'      => 'fuel_type',
		'transmission'   => 'transmission',
		'engine_size'    => 'engine_size',
		'drivetrain'      => 'drivetrain',
		'exterior_color' => 'exterior_color',
		'interior_color' => 'interior_color',
		'condition'      => 'condition_key',
	);

	private const SORTS = array(
		'newest'      => 'v.created_at DESC, v.id DESC',
		'price_asc'   => 'v.retail_price ASC, v.id DESC',
		'price_desc'  => 'v.retail_price DESC, v.id DESC',
		'year_desc'   => 'v.model_year DESC, v.id DESC',
		'mileage_asc' => 'v.mileage ASC, v.id DESC',
	);

	public static function boot(): void {
		add_action( 'pre_get_posts', array( self::class, 'prepare_theme_query' ), 12 );
		add_filter( 'posts_clauses', array( self::class, 'filter_car_queries' ), 20, 2 );
	}

	public static function mode(): string {
		$mode = sanitize_key( (string) get_option( self::OPTION_MODE, self::MODE_COMPATIBILITY ) );
		return in_array( $mode, array( self::MODE_AUTHORITATIVE, 'models' ), true ) ? $mode : self::MODE_COMPATIBILITY;
	}

	/** Authoritative reads require an explicitly selected mode and a verified schema. */
	public static function is_authoritative(): bool {
		return self::MODE_AUTHORITATIVE === self::mode() && get_option( 'adc_db_version' ) === Schema::VERSION;
	}

	/** Marks the public car archive for database-backed filtering and sorting. */
	public static function prepare_theme_query( \WP_Query $query ): void {
		if ( is_admin() || ! $query->is_main_query() || ! $query->is_post_type_archive( 'car' ) ) {
			return;
		}

		$raw = wp_unslash( $_GET );
		$filters = self::normalize_filters( is_array( $raw ) ? $raw : array(), true );
		$filters['per_page'] = 24;
		$query->set( 'adc_public_catalog', true );
		$query->set( 'adc_catalog_filters', $filters );
		$query->set( 'posts_per_page', 24 );
		// The catalog owns search in both modes, including header requests using `search`.
		$query->set( 's', '' );
		if ( ! self::is_authoritative() && ! GroupedModelCatalog::enabled() ) { return; }

		// Avoid legacy taxonomy and WordPress search constraints in authoritative mode.
		$query->set( 'car_brand', '' );
		$query->set( 'car_category', '' );
		$query->set( 's', '' );
	}

	/** Applies central availability to every car query and full filters to opted-in queries. */
	public static function filter_car_queries( array $clauses, \WP_Query $query ): array {
		if ( is_admin() || $query->is_preview() || ! self::is_car_query( $query ) ) {
			return $clauses;
		}

		global $wpdb;
		$posts = $wpdb->posts;
		if ( GroupedModelCatalog::enabled() ) { return GroupedModelCatalog::clauses( $clauses, $query ); }
		if ( get_option( 'adc_db_version' ) === Schema::VERSION ) { $clauses = GroupedModelCatalog::filter_linked_availability( $clauses ); }
		if ( ! self::is_authoritative() && $query->get( 'adc_public_catalog' ) ) {
			$clauses = self::compatibility_clauses( $clauses, (array) $query->get( 'adc_catalog_filters' ) );
		}
		$legacy_status = "COALESCE((SELECT adc_inventory_meta.meta_value FROM {$wpdb->postmeta} adc_inventory_meta WHERE adc_inventory_meta.post_id = $posts.ID AND adc_inventory_meta.meta_key = '_car_inventory_status' ORDER BY adc_inventory_meta.meta_id ASC LIMIT 1), '') IN ('', 'available')";
		if ( get_option( 'adc_db_version' ) !== Schema::VERSION ) {
			$clauses['where'] .= " AND $legacy_status";
			return $clauses;
		}
		$vehicles = Schema::table( 'vehicles' );
		$branches = Schema::table( 'branches' );
		$authoritative = self::is_authoritative();

		if ( ! $authoritative ) {
			$clauses['where'] .= " AND (
				EXISTS (SELECT 1 FROM $vehicles adc_vehicle
					INNER JOIN $branches adc_branch ON adc_branch.id=adc_vehicle.branch_id AND adc_branch.active=1
					WHERE adc_vehicle.public_post_id=$posts.ID AND adc_vehicle.status='available'
					AND NOT EXISTS (SELECT 1 FROM $vehicles adc_duplicate WHERE adc_duplicate.public_post_id=adc_vehicle.public_post_id AND adc_duplicate.id<>adc_vehicle.id))
				OR (NOT EXISTS (SELECT 1 FROM $vehicles adc_mapping WHERE adc_mapping.public_post_id=$posts.ID) AND $legacy_status)
			)";
			return $clauses;
		}

		$clauses['join'] .= " INNER JOIN $vehicles adc_catalog_vehicle ON adc_catalog_vehicle.public_post_id = $posts.ID INNER JOIN $branches adc_catalog_branch ON adc_catalog_branch.id = adc_catalog_vehicle.branch_id";
		$clauses['where'] .= " AND adc_catalog_vehicle.status = 'available' AND adc_catalog_branch.active = 1 AND NOT EXISTS (SELECT 1 FROM $vehicles adc_catalog_duplicate WHERE adc_catalog_duplicate.public_post_id=adc_catalog_vehicle.public_post_id AND adc_catalog_duplicate.id<>adc_catalog_vehicle.id)";
		$clauses['distinct'] = 'DISTINCT';

		if ( (bool) $query->get( 'adc_public_catalog' ) ) {
			$filters = (array) $query->get( 'adc_catalog_filters' );
			list( $where, $args ) = self::where( $filters, 'adc_catalog_vehicle', "$posts.post_title" );
			if ( $where ) {
				$clauses['where'] .= $wpdb->prepare( ' AND ' . implode( ' AND ', $where ), $args );
			}
			$sort = isset( self::SORTS[ $filters['sort'] ?? '' ] ) ? $filters['sort'] : 'newest';
			$clauses['orderby'] = str_replace( 'v.', 'adc_catalog_vehicle.', self::SORTS[ $sort ] );
			if ( str_starts_with($sort, 'price_') ) { $clauses['orderby'] = str_replace('adc_catalog_vehicle.retail_price', \AutoDealership\Pricing\PublicVehiclePrice::sql('adc_catalog_vehicle.retail_price', "$posts.ID"), $clauses['orderby']); }
		}

		return $clauses;
	}

	/** Returns an eligible public vehicle by its WordPress post mapping. */
	public static function vehicle_for_post( int $post_id ): ?array {
		static $cache = array();
		if ( $post_id < 1 || get_option( 'adc_db_version' ) !== Schema::VERSION ) {
			return null;
		}
		$cache_key = $post_id . ':' . \AutoDealership\Core\Localization::language();
		if ( array_key_exists( $cache_key, $cache ) ) {
			return $cache[ $cache_key ];
		}

		global $wpdb;
		$fields = 'v.id,v.stock_number,v.brand,v.model,v.trim_name,v.model_year,v.condition_key,v.branch_id,v.status,v.body_type,v.fuel_type,v.transmission,v.mileage,v.retail_price,v.currency';
		$fields .= ',v.' . implode( ',v.', VehicleSpecifications::fields() );
		$vehicles = Schema::table( 'vehicles' );
		$sql = 'SELECT ' . $fields . ',b.name branch_name,b.city branch_city,v.public_post_id FROM ' . $vehicles . ' v INNER JOIN ' . Schema::table( 'branches' ) . " b ON b.id=v.branch_id AND b.active=1 INNER JOIN {$wpdb->posts} p ON p.ID=v.public_post_id AND p.post_type='car' AND p.post_status='publish' WHERE v.public_post_id=%d AND v.status='available' AND NOT EXISTS (SELECT 1 FROM $vehicles adc_duplicate WHERE adc_duplicate.public_post_id=v.public_post_id AND adc_duplicate.id<>v.id) LIMIT 1";
		$row = $wpdb->get_row( $wpdb->prepare( $sql, $post_id ), ARRAY_A );
		$cache[ $cache_key ] = $row ? self::cast_item( $row ) : null;
		return $cache[ $cache_key ];
	}

	/** Matches the catalog query's public-visibility rule for comparison and other adapters. */
	public static function is_post_publicly_eligible( int $post_id ): bool {
		if ( $post_id < 1 || 'car' !== get_post_type( $post_id ) || 'publish' !== get_post_status( $post_id ) ) {
			return false;
		}
		if ( GroupedModelCatalog::enabled() || GroupedModelCatalog::is_mapped( $post_id ) ) { return null !== GroupedModelCatalog::view( $post_id ); }
		if ( get_option( 'adc_db_version' ) !== Schema::VERSION ) {
			return in_array( get_post_meta( $post_id, '_car_inventory_status', true ), array( '', 'available' ), true );
		}
		if ( self::vehicle_for_post( $post_id ) ) {
			return true;
		}
		if ( self::is_authoritative() ) {
			return false;
		}

		global $wpdb;
		$count = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Schema::table( 'vehicles' ) . ' WHERE public_post_id=%d', $post_id ) );
		return ! $wpdb->last_error && 0 === (int) $count
			&& in_array( get_post_meta( $post_id, '_car_inventory_status', true ), array( '', 'available' ), true );
	}

	/** Public REST/read-model list. Monetary filters use stored minor units. */
	public static function catalog( array $raw_filters = array() ): array {
		if ( GroupedModelCatalog::enabled() ) { return GroupedModelCatalog::catalog( self::normalize_filters( $raw_filters ) ); }
		global $wpdb;
		$filters = self::normalize_filters( $raw_filters );
		$page = max( 1, absint( $filters['page'] ?? 1 ) );
		$limit = min( 48, max( 1, absint( $filters['per_page'] ?? 12 ) ) );
		list( $where, $args ) = self::where( $filters );
		$fields = 'v.' . implode( ',v.', VehicleSpecifications::fields() );
		$fields .= ',v.id,v.stock_number,v.brand,v.model,v.trim_name,v.model_year,v.condition_key,v.branch_id,v.status,v.body_type,v.fuel_type,v.transmission,v.mileage,v.retail_price,v.currency';
		$sort = isset( self::SORTS[ $filters['sort'] ?? '' ] ) ? $filters['sort'] : 'newest';
		$vehicles = Schema::table( 'vehicles' );
		$sql = 'SELECT ' . $fields . ',b.name branch_name,b.city branch_city,p.ID public_post_id FROM ' . $vehicles . ' v INNER JOIN ' . Schema::table( 'branches' ) . " b ON b.id=v.branch_id AND b.active=1 INNER JOIN {$wpdb->posts} p ON p.ID=v.public_post_id AND p.post_type='car' AND p.post_status='publish' WHERE v.status='available' AND NOT EXISTS (SELECT 1 FROM $vehicles adc_duplicate WHERE adc_duplicate.public_post_id=v.public_post_id AND adc_duplicate.id<>v.id)";
		if ( $where ) {
			$sql .= ' AND ' . implode( ' AND ', $where );
		}
		$order = self::SORTS[$sort];
		if ( str_starts_with($sort, 'price_') ) { $order = str_replace('v.retail_price', \AutoDealership\Pricing\PublicVehiclePrice::sql('v.retail_price', 'v.public_post_id'), $order); }
		$sql .= ' ORDER BY ' . $order . ' LIMIT %d OFFSET %d';
		$args[] = $limit;
		$args[] = ( $page - 1 ) * $limit;
		$items = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) ?: array();
		\AutoDealership\Content\StoredTranslations::prime( 'vehicles', wp_list_pluck( $items, 'id' ) );
		\AutoDealership\Content\StoredTranslations::prime( 'branches', wp_list_pluck( $items, 'branch_id' ) );
		$post_ids = array_values( array_filter( array_map( 'absint', wp_list_pluck( $items, 'public_post_id' ) ) ) );
		if ( $post_ids && function_exists( '_prime_post_caches' ) ) {
			_prime_post_caches( $post_ids, true, true );
		}

		return GroupedModelCatalog::with_mappings( $post_ids, static function () use ( $items ): array {
			foreach ( $items as &$item ) {
				$item = self::cast_item( $item );
				$post_id = $item['public_post_id'];
				$item['price_breakdown'] = \AutoDealership\Pricing\PublicVehiclePrice::public_breakdown(\AutoDealership\Pricing\PublicVehiclePrice::calculate((int)$item['retail_price'], $post_id));
				$item['retail_price'] = $item['price_breakdown']['final_amount'];
				$item['title'] = get_the_title( $post_id );
				$item['url'] = get_permalink( $post_id );
				$item['image'] = get_the_post_thumbnail_url( $post_id, 'large' ) ?: '';
				unset( $item['public_post_id'] );
			}
			unset( $item );
			return $items;
		} );
	}

	public static function catalog_total( array $raw_filters = array() ): int {
		if ( GroupedModelCatalog::enabled() ) { return (int) GroupedModelCatalog::query( self::normalize_filters( $raw_filters ) )->found_posts; }
		global $wpdb;
		$filters = self::normalize_filters( $raw_filters );
		list( $where, $args ) = self::where( $filters );
		$vehicles = Schema::table( 'vehicles' );
		$sql = 'SELECT COUNT(DISTINCT v.id) FROM ' . $vehicles . ' v INNER JOIN ' . Schema::table( 'branches' ) . " b ON b.id=v.branch_id AND b.active=1 INNER JOIN {$wpdb->posts} p ON p.ID=v.public_post_id AND p.post_type='car' AND p.post_status='publish' WHERE v.status='available' AND NOT EXISTS (SELECT 1 FROM $vehicles adc_duplicate WHERE adc_duplicate.public_post_id=v.public_post_id AND adc_duplicate.id<>v.id)";
		if ( $where ) {
			$sql .= ' AND ' . implode( ' AND ', $where );
		}
		return (int) $wpdb->get_var( $args ? $wpdb->prepare( $sql, $args ) : $sql );
	}

	/** Values for public filter controls, bounded to eligible catalog records. */
	public static function filter_options(): array {
		if ( GroupedModelCatalog::enabled() ) { return GroupedModelCatalog::options(); }
		global $wpdb;
		$options = array();
		$table = Schema::table( 'vehicles' );
		$branches = Schema::table( 'branches' );
		$base = " FROM $table v INNER JOIN $branches b ON b.id=v.branch_id AND b.active=1 INNER JOIN {$wpdb->posts} p ON p.ID=v.public_post_id AND p.post_type='car' AND p.post_status='publish' WHERE v.status='available' AND NOT EXISTS (SELECT 1 FROM $table adc_duplicate WHERE adc_duplicate.public_post_id=v.public_post_id AND adc_duplicate.id<>v.id)";
		foreach ( array( 'brand', 'body_type', 'fuel_type', 'transmission', 'condition_key' ) as $field ) {
			$options[ $field ] = $wpdb->get_col( "SELECT DISTINCT v.$field" . $base . " AND v.$field<>'' ORDER BY v.$field ASC LIMIT 250" ) ?: array();
		}
		$options['branches'] = $wpdb->get_results( 'SELECT DISTINCT b.id,b.name,b.city' . $base . ' ORDER BY b.name ASC LIMIT 250', ARRAY_A ) ?: array();
		\AutoDealership\Content\StoredTranslations::prime( 'branches', wp_list_pluck( $options['branches'], 'id' ) );
		foreach ( $options['branches'] as &$branch ) { $branch = \AutoDealership\Content\StoredTranslations::row( 'branches', $branch, true ); }
		unset( $branch );
		return $options;
	}

	/** Presentation choices for both operational and editorial compatibility catalogs. */
	public static function presentation_filter_options(): array {
		if ( GroupedModelCatalog::enabled() ) { return array( 'mode' => self::MODE_AUTHORITATIVE, 'options' => GroupedModelCatalog::options() ); }
		if ( self::is_authoritative() ) {
			return array( 'mode' => self::MODE_AUTHORITATIVE, 'options' => self::filter_options() );
		}
		$result = array( 'mode' => self::MODE_COMPATIBILITY, 'categories' => array(), 'brands' => array() );
		foreach ( array( 'car_category' => 'categories', 'car_brand' => 'brands' ) as $taxonomy => $key ) {
			$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => true ) );
			if ( is_wp_error( $terms ) ) { continue; }
			foreach ( $terms as $term ) {
				$result[ $key ][] = array( 'slug' => $term->slug, 'name' => $term->name );
			}
		}
		return $result;
	}

	/** Administrative cutover counts; no customer or financial fields are returned. */
	public static function readiness(): array {
		if ( GroupedModelCatalog::enabled() ) { return GroupedModelCatalog::readiness(); }
		$schema_ready = get_option( 'adc_db_version' ) === Schema::VERSION;
		$result = array(
			'schema_ready' => $schema_ready,
			'operational' => 0,
			'eligible' => 0,
			'published_posts' => 0,
			'unmapped_published_posts' => 0,
			'duplicate_mappings' => 0,
			'invalid_mappings' => 0,
			'ready' => false,
		);
		if ( ! $schema_ready ) {
			return $result;
		}

		global $wpdb;
		$vehicles = Schema::table( 'vehicles' );
		$branches = Schema::table( 'branches' );
		$error = false;
		$count = static function ( string $sql ) use ( $wpdb, &$error ): int {
			$value = $wpdb->get_var( $sql );
			if ( $wpdb->last_error ) {
				$error = true;
			}
			return (int) $value;
		};

		$result['operational'] = $count( "SELECT COUNT(*) FROM $vehicles" );
		$result['published_posts'] = $count( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='car' AND post_status='publish'" );
		$result['unmapped_published_posts'] = $count( "SELECT COUNT(*) FROM {$wpdb->posts} p WHERE p.post_type='car' AND p.post_status='publish' AND NOT EXISTS (SELECT 1 FROM $vehicles v WHERE v.public_post_id=p.ID)" );
		$result['duplicate_mappings'] = $count( "SELECT COUNT(*) FROM (SELECT public_post_id FROM $vehicles WHERE public_post_id>0 GROUP BY public_post_id HAVING COUNT(*)>1) adc_duplicates" );
		$result['invalid_mappings'] = $count( "SELECT COUNT(*) FROM $vehicles v LEFT JOIN {$wpdb->posts} p ON p.ID=v.public_post_id WHERE v.public_post_id>0 AND (p.ID IS NULL OR p.post_type<>'car' OR p.post_status<>'publish')" );
		$result['eligible'] = $count( "SELECT COUNT(*) FROM $vehicles v INNER JOIN $branches b ON b.id=v.branch_id AND b.active=1 INNER JOIN {$wpdb->posts} p ON p.ID=v.public_post_id AND p.post_type='car' AND p.post_status='publish' WHERE v.status='available' AND NOT EXISTS (SELECT 1 FROM $vehicles adc_duplicate WHERE adc_duplicate.public_post_id=v.public_post_id AND adc_duplicate.id<>v.id)" );
		$result['ready'] = ! $error
			&& $result['operational'] > 0
			&& $result['published_posts'] > 0
			&& $result['eligible'] > 0
			&& 0 === $result['unmapped_published_posts']
			&& 0 === $result['duplicate_mappings']
			&& 0 === $result['invalid_mappings'];
		return $result;
	}

	/** Normalizes shared REST or theme URL filters. */
	public static function normalize_filters( array $raw, bool $major_price_units = false ): array {
		$filters = array();
		$aliases = array( 'fuel' => 'fuel_type', 'car_category' => 'body_type' );
		foreach ( $aliases as $old => $new ) {
			if ( ! isset( $raw[ $new ] ) && isset( $raw[ $old ] ) ) {
				$raw[ $new ] = $raw[ $old ];
			}
		}
		foreach ( array_keys( self::TEXT_FILTERS ) as $key ) {
			if ( isset( $raw[ $key ] ) && is_scalar( $raw[ $key ] ) && '' !== trim( (string) $raw[ $key ] ) ) {
				$limit = in_array( $key, array( 'brand', 'model', 'trim' ), true ) ? 120 : ( in_array( $key, array( 'exterior_color', 'interior_color' ), true ) ? 80 : 40 );
				$filters[ $key ] = mb_substr( sanitize_text_field( (string) $raw[ $key ] ), 0, $limit );
			}
		}
		foreach ( array( 'min_year', 'max_year', 'min_price', 'max_price', 'min_mileage', 'max_mileage', 'branch_id' ) as $key ) {
			if ( isset( $raw[ $key ] ) && is_scalar( $raw[ $key ] ) && '' !== (string) $raw[ $key ] ) {
				$filters[ $key ] = max( 0, absint( $raw[ $key ] ) );
			}
		}
		if ( isset( $raw['model_year'] ) && is_scalar( $raw['model_year'] ) && '' !== (string) $raw['model_year'] ) {
			$filters['min_year'] = $filters['max_year'] = absint( $raw['model_year'] );
		}
		if ( $major_price_units ) {
			foreach ( array( 'min_price', 'max_price' ) as $key ) {
				if ( isset( $filters[ $key ] ) ) {
					$minor = \AutoDealership\Pricing\Money::from_sar( (string) $raw[$key] );
					if ( null === $minor ) { unset( $filters[$key] ); }
					else { $filters[$key] = $minor; }
				}
			}
		}
		if ( isset( $raw['s'] ) && is_scalar( $raw['s'] ) && '' !== trim( (string) $raw['s'] ) ) {
			$filters['search'] = mb_substr( sanitize_text_field( (string) $raw['s'] ), 0, 120 );
		} elseif ( isset( $raw['search'] ) && is_scalar( $raw['search'] ) ) {
			$filters['search'] = mb_substr( sanitize_text_field( (string) $raw['search'] ), 0, 120 );
		}
		$sort = sanitize_key( (string) ( $raw['sort'] ?? 'newest' ) );
		$filters['sort'] = isset( self::SORTS[ $sort ] ) ? $sort : 'newest';
		$filters['page'] = max( 1, absint( $raw['page'] ?? 1 ) );
		$filters['per_page'] = min( 48, max( 1, absint( $raw['per_page'] ?? 12 ) ) );
		return $filters;
	}

	private static function where( array $filters, string $alias = 'v', string $title = 'p.post_title' ): array {
		global $wpdb;
		$where = array();
		$args = array();
		foreach ( self::TEXT_FILTERS as $key => $column ) {
			if ( isset( $filters[ $key ] ) && '' !== $filters[ $key ] ) {
				$where[] = "$alias.$column = %s";
				$args[] = $filters[ $key ];
			}
		}
		foreach ( array( 'min_year' => array( 'model_year', '>=' ), 'max_year' => array( 'model_year', '<=' ), 'min_price' => array( 'retail_price', '>=' ), 'max_price' => array( 'retail_price', '<=' ), 'min_mileage' => array( 'mileage', '>=' ), 'max_mileage' => array( 'mileage', '<=' ), 'branch_id' => array( 'branch_id', '=' ) ) as $key => $rule ) {
			if ( isset( $filters[ $key ] ) && ( 'branch_id' !== $key || $filters[ $key ] > 0 ) ) {
				$expression = $rule[0] === 'retail_price' ? \AutoDealership\Pricing\PublicVehiclePrice::sql("$alias.retail_price", "$alias.public_post_id") : "$alias.{$rule[0]}";
				$where[] = "$expression {$rule[1]} %d";
				$args[] = $filters[ $key ];
			}
		}
		foreach ( preg_split( '/\s+/u', trim( (string) ( $filters['search'] ?? '' ) ), -1, PREG_SPLIT_NO_EMPTY ) ?: array() as $word ) {
			$like = '%' . $wpdb->esc_like( $word ) . '%';
			$where[] = "($alias.brand LIKE %s OR $alias.model LIKE %s OR $alias.trim_name LIKE %s OR $alias.stock_number LIKE %s OR CAST($alias.model_year AS CHAR) LIKE %s OR $title LIKE %s)";
			array_push( $args, $like, $like, $like, $like, $like, $like );
		}
		return array( $where, $args );
	}

	/** Apply filters to the same operational-or-editorial values used by vehicle cards. */
	private static function compatibility_clauses( array $clauses, array $filters ): array {
		global $wpdb;
		$posts = $wpdb->posts;
		$schema_ready = get_option( 'adc_db_version' ) === Schema::VERSION;
		$value = static function ( string $meta, string $column, bool $price = false ) use ( $wpdb, $posts, $schema_ready ): string {
			$legacy = $wpdb->prepare( "(SELECT cm.meta_value FROM {$wpdb->postmeta} cm WHERE cm.post_id=$posts.ID AND cm.meta_key=%s ORDER BY cm.meta_id ASC LIMIT 1)", $meta );
			if ( $price ) { $legacy = "ROUND(CAST($legacy AS DECIMAL(20,2))*100)"; }
			$result = $legacy;
			if ( $schema_ready ) {
				$table = Schema::table('vehicles'); $branches = Schema::table('branches');
				$result = "COALESCE((SELECT cv.$column FROM $table cv INNER JOIN $branches cb ON cb.id=cv.branch_id AND cb.active=1 WHERE cv.public_post_id=$posts.ID AND cv.status='available' LIMIT 1), $legacy)";
				if ( $price || $column === 'model_year' ) {
					$stock = Schema::table('onyx_stock'); $models = Schema::table('catalog_models');
					$source = $price ? 'listed_price' : 'model_year';
					$result = "COALESCE((SELECT MIN(NULLIF(s.$source,0)) FROM $stock s INNER JOIN $models gm ON gm.id=s.model_id WHERE gm.public_post_id=$posts.ID AND ".GroupedModelCatalog::availability()."), $result)";
				}
			}
			return $price ? \AutoDealership\Pricing\PublicVehiclePrice::sql($result, "$posts.ID") : $result;
		};
		foreach ( array( 'model' => array( '_car_model', 'model' ), 'fuel_type' => array( '_car_fuel_type', 'fuel_type' ), 'transmission' => array( '_car_transmission', 'transmission' ) ) as $key => $field ) {
			if ( ! empty( $filters[$key] ) ) {
				$expression = $value( $field[0], $field[1] );
				$clauses['where'] .= $wpdb->prepare( " AND $expression " . ( 'model' === $key ? 'LIKE %s' : '= %s' ), 'model' === $key ? '%' . $wpdb->esc_like( $filters[$key] ) . '%' : $filters[$key] );
			}
		}
		foreach ( array( 'min_year' => array( '_car_year', 'model_year', '>=' ), 'max_year' => array( '_car_year', 'model_year', '<=' ), 'min_price' => array( '_car_price', 'retail_price', '>=' ), 'max_price' => array( '_car_price', 'retail_price', '<=' ) ) as $key => $field ) {
			if ( ! isset( $filters[$key] ) ) { continue; }
			$is_price = str_contains( $key, 'price' );
			$expression = $value( $field[0], $field[1], $is_price );
			$amount = $filters[$key];
			$clauses['where'] .= $wpdb->prepare( " AND NULLIF($expression, '') IS NOT NULL AND CAST($expression AS DECIMAL(20,2)) {$field[2]} %f", $amount );
		}
		foreach ( preg_split( '/\s+/u', trim( (string) ( $filters['search'] ?? '' ) ), -1, PREG_SPLIT_NO_EMPTY ) ?: array() as $word ) {
			$like = '%' . $wpdb->esc_like( $word ) . '%';
			$operational_search = '';
			if ( $schema_ready ) {
				$table = Schema::table( 'vehicles' );
				$operational_search = $wpdb->prepare( " OR EXISTS (SELECT 1 FROM $table sv WHERE sv.public_post_id=$posts.ID AND (sv.brand LIKE %s OR sv.model LIKE %s OR sv.trim_name LIKE %s OR sv.stock_number LIKE %s OR CAST(sv.model_year AS CHAR) LIKE %s))", $like, $like, $like, $like, $like );
			}
			$clauses['where'] .= $wpdb->prepare( " AND ($posts.post_title LIKE %s
				OR EXISTS (SELECT 1 FROM {$wpdb->postmeta} sm WHERE sm.post_id=$posts.ID AND sm.meta_key IN ('_car_model','_car_make','_car_trim','_car_stock_number','_car_stock','_car_year','_adc_title_en') AND sm.meta_value LIKE %s)
				OR EXISTS (SELECT 1 FROM {$wpdb->term_relationships} sr INNER JOIN {$wpdb->term_taxonomy} st ON st.term_taxonomy_id=sr.term_taxonomy_id INNER JOIN {$wpdb->terms} sn ON sn.term_id=st.term_id LEFT JOIN {$wpdb->termmeta} sl ON sl.term_id=sn.term_id AND sl.meta_key IN ('_adc_name_ar','_adc_name_en') WHERE sr.object_id=$posts.ID AND st.taxonomy IN ('car_brand','car_category') AND (sn.name LIKE %s OR sn.slug LIKE %s OR sl.meta_value LIKE %s))", $like, $like, $like, $like, $like ) . $operational_search . ')';
		}
		if ( in_array($filters['sort'] ?? '', array('price_asc', 'price_desc'), true) ) { $clauses['orderby'] = $value('_car_price', 'retail_price', true).(($filters['sort'] === 'price_asc') ? ' ASC' : ' DESC').", $posts.ID DESC"; }
		return $clauses;
	}

	private static function cast_item( array $item ): array {
		foreach ( array( 'id', 'model_year', 'branch_id', 'mileage', 'retail_price', 'doors', 'seats', 'horsepower', 'cylinders', 'public_post_id' ) as $key ) {
			if ( array_key_exists( $key, $item ) && null !== $item[ $key ] ) {
				$item[ $key ] = (int) $item[ $key ];
			}
		}
		if ( array_key_exists( 'gallery_media_ids', $item ) ) {
			$ids = json_decode( (string) $item['gallery_media_ids'], true );
			$item['gallery_media_ids'] = is_array( $ids ) ? array_values( array_filter( array_map( 'absint', $ids ) ) ) : array();
		}
		$item = \AutoDealership\Content\StoredTranslations::row( 'vehicles', $item, true );
		foreach ( array( 'branch_name' => 'name', 'branch_city' => 'city' ) as $key => $field ) {
			if ( isset( $item[$key] ) ) { $item[$key] = \AutoDealership\Content\StoredTranslations::text( 'branches', (int) $item['branch_id'], $field, (string) $item[$key], true ); }
		}
		return $item;
	}

	private static function is_car_query( \WP_Query $query ): bool {
		if ( $query->is_singular( 'car' ) || $query->is_post_type_archive( 'car' ) ) {
			return true;
		}
		$post_type = $query->get( 'post_type' );
		return 'car' === $post_type || ( is_array( $post_type ) && in_array( 'car', $post_type, true ) );
	}
}
