<?php
namespace AutoDealership\Accounts;

use AutoDealership\Database\Schema;
use AutoDealership\Inventory\PublicCatalog;
use AutoDealership\Leads\LegacyEngagementStore;
use AutoDealership\Leads\RequestWorkflow;

defined( 'ABSPATH' ) || exit;

/** Bounded account history read model, scoped only by the authenticated account ID. */
final class CustomerRequestView {
	public const PER_PAGE = 10;

	public static function enabled(): bool {
		return (bool) apply_filters( 'adc_core_customer_request_view_enabled', true );
	}

	/** @return array<string,mixed>|\WP_Error */
	public static function page( string $type, int $page = 1, array $filters = array() ) {
		global $wpdb;
		$user_id = get_current_user_id();
		if ( ! $user_id || ! in_array( $type, array( 'messages', 'bookings' ), true ) ) {
			return self::error( 'adc_customer_requests_forbidden', 403 );
		}
		if ( ! Schema::is_ready() || ! LegacyEngagementStore::is_ready() ) {
			return self::error( 'adc_customer_requests_unavailable', 503 );
		}
		$page = min( 10000, max( 1, $page ) );
		$table = $wpdb->prefix . ( 'bookings' === $type ? 'car_dealer_bookings' : 'car_dealer_messages' );
		$fields = 'r.id,r.car_id,r.status,r.customer_reply,r.created_at,r.updated_at';
		if ( 'bookings' === $type ) {
			$fields .= ',r.requested_date,r.requested_time';
			$fields .= ',EXISTS (SELECT 1 FROM ' . Schema::table( 'leads' ) . ' linked INNER JOIN ' . Schema::table( 'customers' ) . " owner ON owner.id=linked.customer_id AND owner.account_user_id=%d AND owner.merged_into_id IS NULL WHERE linked.legacy_request_type='booking' AND linked.legacy_request_id=r.id) AS linked";
		} else {
			$fields .= ',r.message,r.lead_type,r.subject';
		}
		$args = 'bookings' === $type ? array( $user_id, $user_id ) : array( $user_id );
		$where = '';
		if ( 'upcoming' === ( $filters['status'] ?? '' ) && 'bookings' === $type ) { $where .= " AND r.status IN ('pending','confirmed') AND CONCAT(r.requested_date,' ',r.requested_time)>=%s"; $args[] = current_time('mysql'); }
		if ( 'open' === ( $filters['status'] ?? '' ) && 'messages' === $type ) { $where .= " AND r.status IN ('new','read')"; }
		if ( ! empty( $filters['request'] ) ) { $where .= ' AND r.id=%d'; $args[] = absint( $filters['request'] ); }
		$statuses = RequestWorkflow::statuses( 'bookings' === $type ? 'booking' : 'message' );
		if ( isset( $statuses[$filters['status'] ?? ''] ) ) { $where .= ' AND r.status=%s'; $args[] = $filters['status']; }
		if ( ! empty( $filters['search'] ) ) {
			$like = '%' . $wpdb->esc_like( mb_substr( sanitize_text_field( $filters['search'] ), 0, 100 ) ) . '%';
			$where .= ' AND (CAST(r.id AS CHAR) LIKE %s' . ( 'bookings' === $type ? ')' : ' OR r.subject LIKE %s OR r.message LIKE %s)' );
			$args[] = $like;
			if ( 'bookings' !== $type ) { $args[] = $like; $args[] = $like; }
		}
		foreach ( array( 'from'=>'>=', 'to'=>'<=' ) as $key=>$operator ) {
			if ( ! empty( $filters[$key] ) && preg_match( '/\A\d{4}-\d{2}-\d{2}\z/', $filters[$key] ) ) {
				$where .= ' AND ' . ( 'bookings' === $type ? 'r.requested_date' : 'r.created_at' ) . " $operator %s";
				// Request dates are stored in UTC; date filters refer to the site's local calendar.
				$args[] = 'bookings' === $type ? $filters[$key] : get_gmt_from_date( $filters[$key] . ( 'from' === $key ? ' 00:00:00' : ' 23:59:59' ) );
			}
		}
		$args[] = self::PER_PAGE + 1; $args[] = ( $page - 1 ) * self::PER_PAGE;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT $fields FROM $table r WHERE r.user_id=%d $where ORDER BY r.id DESC LIMIT %d OFFSET %d",
				$args
			),
			ARRAY_A
		);
		if ( null === $rows || $wpdb->last_error ) {
			return self::error( 'adc_customer_requests_unavailable', 503 );
		}
		$more = count( $rows ) > self::PER_PAGE;
		$items = array();
		$statuses = RequestWorkflow::statuses( 'bookings' === $type ? 'booking' : 'message' );
		foreach ( array_slice( $rows, 0, self::PER_PAGE ) as $row ) {
			$car_id = (int) $row['car_id'];
			$car_visible = $car_id && PublicCatalog::is_post_publicly_eligible( $car_id )
				&& ( PublicCatalog::vehicle_for_post( $car_id ) || in_array( get_post_meta( $car_id, '_car_inventory_status', true ), array( '', 'available' ), true ) );
			$items[] = array(
				'id' => (int) $row['id'],
				'car_id' => $car_id,
				'car_title' => $car_visible ? (string) get_the_title( $car_id ) : '',
				'car_url' => $car_visible ? (string) get_permalink( $car_id ) : '',
				'status' => (string) $row['status'],
				'status_label' => $statuses[ $row['status'] ] ?? __( 'قيد المتابعة', 'auto-dealership-core' ),
				'message' => 'messages' === $type ? (string) $row['message'] : '',
				'request_kind' => 'messages' === $type ? (string) $row['lead_type'] : 'test_drive',
				'subject' => 'messages' === $type ? (string) $row['subject'] : '',
				'customer_reply' => (string) $row['customer_reply'],
				'requested_date' => 'bookings' === $type ? (string) $row['requested_date'] : '',
				'requested_time' => 'bookings' === $type ? (string) $row['requested_time'] : '',
				'created_at' => (string) $row['created_at'],
				'updated_at' => (string) ( $row['updated_at'] ?? '' ),
				'can_cancel' => 'bookings' === $type && ! empty( $row['linked'] ) && in_array( $row['status'], array( 'pending', 'confirmed' ), true ),
		);
		}
		return array( 'items' => $items, 'page' => $page, 'has_more' => $more );
	}

	private static function error( string $code, int $status ): \WP_Error {
		return new \WP_Error( $code, __( 'تعذر تحميل طلبات الحساب حاليًا. حاول مجددًا لاحقًا.', 'auto-dealership-core' ), array( 'status' => $status ) );
	}
}
