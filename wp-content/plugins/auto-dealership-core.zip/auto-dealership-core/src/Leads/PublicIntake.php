<?php
namespace AutoDealership\Leads;

use AutoDealership\Database\Schema;
use AutoDealership\Inventory\PublicCatalog;
use AutoDealership\Inventory\VehicleService;
use AutoDealership\Pricing\Money;
use AutoDealership\Security\PublicRequestGuard;

defined( 'ABSPATH' ) || exit;

/** One public boundary for REST enquiries and the theme's contact/test-drive forms. */
final class PublicIntake {
	private static bool $booted = false;

	public static function enabled(): bool { return (bool) apply_filters( 'adc_core_public_intake_enabled', true ); }

	public static function owns_theme_actions(): bool { return self::enabled(); }

	public static function boot(): void {
		if ( self::$booted || ! self::enabled() ) { return; }
		self::$booted = true;
		add_action( 'wp_ajax_car_dealer_contact', array( self::class, 'handle_message' ) );
		add_action( 'wp_ajax_nopriv_car_dealer_contact', array( self::class, 'handle_message' ) );
		add_action( 'wp_ajax_car_dealer_booking', array( self::class, 'handle_booking' ) );
		add_action( 'wp_ajax_nopriv_car_dealer_booking', array( self::class, 'handle_booking' ) );
		add_action( 'wp_ajax_car_dealer_lead', array( self::class, 'handle_lead' ) );
		add_action( 'wp_ajax_nopriv_car_dealer_lead', array( self::class, 'handle_lead' ) );
	}

	public static function handle_message(): void { self::handle_theme( 'message' ); }
	public static function handle_booking(): void { self::handle_theme( 'booking' ); }
	public static function handle_lead(): void { self::handle_theme( 'lead' ); }

	public static function enqueue(): void {
		if ( self::enabled() || MarketingSubscription::enabled() ) {
			wp_enqueue_script( 'adc-public-intake', plugins_url( 'assets/js/public-intake.js', ADC_FILE ), array(), ADC_VERSION, true );
			wp_localize_script( 'adc-public-intake', 'adcPublicIntake', array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'car_dealer_frontend' ),
				'sendingLabel' => __( 'جاري الإرسال…', 'auto-dealership-core' ),
				'errorLabel' => __( 'تعذر إرسال الطلب الآن.', 'auto-dealership-core' ),
				'unconfirmedLabel' => __( 'لم يتم تأكيد حفظ الطلب. حاول مجددًا.', 'auto-dealership-core' ),
				'accountLabel' => __( 'عرض الطلب في حسابي', 'auto-dealership-core' ),
				'englishLabels' => array(
					'sendingLabel' => 'Sending…',
					'errorLabel' => 'The request could not be sent right now.',
					'unconfirmedLabel' => 'We could not confirm that the request was saved. Please try again.',
					'accountLabel' => 'View request in my account',
				),
			) );
		}
	}

	public static function submit( array $input, string $compatibility_type = '' ) {
		global $wpdb;
		if ( ! Schema::is_ready() ) { return self::error( 'adc_schema_unavailable', 503 ); }
		foreach ( array( 'website'=>200, 'message'=>4000, 'request_kind'=>32, 'date'=>10, 'time'=>5, 'idempotency_key'=>36, 'external_id'=>190, 'utm_source'=>120, 'utm_medium'=>120, 'utm_campaign'=>190, 'utm_content'=>190, 'campaign'=>190, 'platform'=>80, 'landing_page'=>500, 'referrer_url'=>500 ) as $key => $limit ) {
			if ( isset( $input[$key] ) && ( ! is_string( $input[$key] ) || mb_strlen( $input[$key] ) > $limit ) ) { return self::error( 'adc_invalid_lead', 400 ); }
		}
		if ( ! empty( $input['website'] ) || ! in_array( $compatibility_type, array( '', 'message','booking' ), true ) ) { return self::error( 'adc_invalid_lead', 400 ); }
		$identity = ContactIdentity::normalize( $input );
		if ( is_wp_error( $identity ) ) { return $identity; }
		if ( $compatibility_type && ( mb_strlen( $identity['name'] ) > 120 || '' === $identity['email'] ) ) { return self::error( 'adc_invalid_lead', 400 ); }
		$branch = Money::parse( $input['branch_id'] ?? 0 );
		$post_id = Money::parse( $input['car_id'] ?? 0 );
		$key = strtolower( $input['idempotency_key'] ?? '' );
		$kind = 'booking' === $compatibility_type ? 'test_drive' : ( $input['request_kind'] ?? 'contact' );
		if ( null === $branch || null === $post_id || ! in_array( $kind, array( 'contact','finance','finance_request','price_request','offer_request','test_drive','purchase' ), true ) || ( '' !== $key && ! preg_match( '/\A[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\z/', $key ) ) ) { return self::error( 'adc_invalid_lead', 400 ); }
		if ( 'purchase' === $kind && empty( $input['purchase_consent'] ) ) { return self::error( 'adc_purchase_consent_required', 400 ); }
		if ( $post_id ) {
			if ( ! PublicCatalog::is_post_publicly_eligible( $post_id ) ) { return self::error( 'adc_intake_vehicle_unavailable', 400 ); }
			$vehicle = $wpdb->get_row( $wpdb->prepare( 'SELECT branch_id,status FROM ' . Schema::table( 'vehicles' ) . ' WHERE public_post_id=%d LIMIT 1', $post_id ), ARRAY_A );
			if ( $wpdb->last_error ) { return self::error( 'adc_intake_unavailable', 503 ); }
			if ( $vehicle ) {
				if ( 'available' !== $vehicle['status'] || ! VehicleService::branch_exists( (int) $vehicle['branch_id'] ) || ( $branch && $branch !== (int) $vehicle['branch_id'] ) ) { return self::error( 'adc_intake_vehicle_unavailable', 400 ); }
				$branch = (int) $vehicle['branch_id'];
			}
		}
		if ( ! $branch ) { $branch = (int) get_option( 'adc_default_branch_id', 0 ); }
		if ( $branch < 0 || ( $branch && ! VehicleService::branch_exists( $branch ) ) ) { return self::error( 'adc_invalid_lead', 400 ); }
		$date = $input['date'] ?? ''; $time = $input['time'] ?? '';
		if ( 'test_drive' === $kind ) {
			if ( ! preg_match( '/\A[0-9]{4}-[0-9]{2}-[0-9]{2}\z/', $date ) || ! preg_match( '/\A[0-9]{2}:[0-9]{2}\z/', $time ) ) { return self::error( 'adc_invalid_booking_time', 400 ); }
			$when = \DateTimeImmutable::createFromFormat( '!Y-m-d H:i', $date . ' ' . $time, wp_timezone() );
			if ( ! $post_id || ! $when || $when->format( 'Y-m-d H:i' ) !== $date . ' ' . $time || $when->getTimestamp() <= time() ) { return self::error( 'adc_invalid_booking_time', 400 ); }
		} elseif ( '' !== $date || '' !== $time ) { return self::error( 'adc_invalid_lead', 400 ); }
		$selected_variant=null;
		if(isset($input['vehicle_option'])&&$input['vehicle_option']!==''){
			if(!$post_id||!is_string($input['vehicle_option'])||!preg_match('/^[a-f0-9]{64}$/D',$input['vehicle_option'])){return self::error('adc_invalid_lead',400);}
			$selected_variant=\AutoDealership\Inventory\VehicleColors::selected($post_id,$input['vehicle_option']);
			if(!$selected_variant){return self::error('adc_intake_vehicle_unavailable',400);}
		}
		$message = sanitize_textarea_field( $input['message'] ?? '' );
		if ( 'message' === $compatibility_type && 'contact' === $kind && '' === trim( $message ) ) { return self::error( 'adc_invalid_lead', 400 ); }
		$context = 'Request: ' . $kind;
		if ( $post_id ) { $context .= "\nVehicle post: " . $post_id; }
		if($selected_variant){$context.="\nOnyx option: ".$selected_variant['full_name']."\nOnyx color: ".$selected_variant['exterior_color']."\nPublic price at request: ".\AutoDealership\Inventory\VehicleColors::price_label($selected_variant);}
		if ( $date ) { $context .= "\nRequested appointment: $date $time (" . wp_timezone_string() . ')'; }
		if ( '' !== $message ) { $context .= "\n" . $message; }
		$rate = PublicRequestGuard::consume( 'intake' );
		if ( is_wp_error( $rate ) ) { return $rate; }
		return LeadService::create_public( array_merge( $input, $identity, array( 'branch_id'=>$branch, 'idempotency_key'=>$key, 'request_kind'=>$kind, 'car_id'=>$post_id, 'date'=>$date, 'time'=>$time, 'message'=>$message, 'public_intake'=>true ) ), null, $context, $compatibility_type );
	}

	/** Theme adapter retains nonce, logged-in identity and existing response shape. */
	public static function handle_theme( string $type ): void {
		if ( ! in_array( $type, array( 'message', 'booking', 'lead' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'نوع الطلب غير صالح.', 'auto-dealership-core' ) ), 400 );
		}
		check_ajax_referer( 'car_dealer_frontend', 'nonce' );
		$input = wp_unslash( $_POST );
		$language = isset( $input['lang'] ) && is_scalar( $input['lang'] ) && 'en' === sanitize_key( (string) $input['lang'] ) ? 'en' : 'ar';
		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();
			$input['name'] = $user->display_name; $input['email'] = $user->user_email;
			$input['mobile'] = get_user_meta( $user->ID, 'car_dealer_phone', true );
		} else { $input['mobile'] = $input['phone'] ?? ''; }
		$input['request_kind'] = $input['lead_type'] ?? $input['type'] ?? 'contact';
		$result = self::submit( $input, 'lead' === $type ? '' : $type );
		if ( is_wp_error( $result ) ) {
			$message = $result->get_error_message();
			if ( 'en' === $language ) {
				$message = array(
					'adc_rate_limited' => 'Too many requests. Please try again later.',
					'adc_invalid_booking_time' => 'Choose a vehicle and a future date and time in the site timezone.',
					'adc_intake_vehicle_unavailable' => 'This vehicle is unavailable for this request.',
					'adc_purchase_consent_required' => 'Please agree that we may contact you about this purchase request.',
				)[ $result->get_error_code() ] ?? 'The request could not be saved. Review the details and try again.';
			}
			wp_send_json_error( array( 'message'=>$message ), (int) ( $result->get_error_data()['status'] ?? 400 ) );
		}
		$data = array( 'message'=>'en' === $language ? 'Your request has been received successfully.' : __( 'تم استلام طلبك بنجاح.', 'auto-dealership-core' ) );
		if ( 'lead' === $type && 'purchase' === (string) ( $input['request_kind'] ?? '' ) && ! empty( $result['id'] ) ) {
			$reference = 'PUR-' . str_pad( (string) absint( $result['id'] ), 6, '0', STR_PAD_LEFT );
			$data['request_reference'] = $reference;
			$data['message'] = 'en' === $language
				? sprintf( 'Your purchase request was received. Reference: %s. Our sales team will contact you shortly.', $reference )
				: sprintf( 'تم استلام طلب الشراء بنجاح. رقم الطلب: %s. سيتواصل معك فريق المبيعات قريبًا.', $reference );
		}
		if ( 'booking' === $type ) {
			$data['booking_id'] = $result['legacy_request_id'];
			$data['account_url'] = is_user_logged_in() ? esc_url_raw( (string) apply_filters( 'adc_customer_account_url', '', 'customer-bookings' ) ) : '';
		}
		wp_send_json_success( $data );
	}

	public static function owns_legacy_request( string $type, int $id ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Schema::table( 'leads' ) . ' WHERE legacy_request_type=%s AND legacy_request_id=%d LIMIT 1', $type, $id ) );
	}

	private static function error( string $code, int $status ): \WP_Error {
		$messages = array( 'adc_rate_limited'=>'تم تجاوز عدد الطلبات المسموح. حاول لاحقًا.', 'adc_invalid_booking_time'=>'اختر سيارة وتاريخًا ووقتًا في المستقبل حسب توقيت الموقع.', 'adc_intake_vehicle_unavailable'=>'السيارة غير متاحة لهذا الطلب.', 'adc_purchase_consent_required'=>'يجب الموافقة على تواصل فريق المبيعات معك بخصوص طلب الشراء.' );
		return new \WP_Error( $code, __( $messages[$code] ?? 'تعذر حفظ الطلب. راجع البيانات أو حاول لاحقًا.', 'auto-dealership-core' ), array( 'status'=>$status ) );
	}
}
