<?php
namespace AutoDealership\Core;

use AutoDealership\Audit\AuditLog;
use AutoDealership\Cache\CacheManager;
use AutoDealership\Database\Schema;

defined( 'ABSPATH' ) || exit;

/** Single-site product onboarding. Never imports operational data or secrets. */
final class ProductSetup {
	private const PROFILE = 'adc_product_profile';
	private const MAIL = 'adc_product_mail';
	private const SECTIONS = array( 'identity', 'appearance', 'policy', 'mail', 'pages', 'readiness' );
	private const PROFILE_KEYS = array( 'brand_ar', 'brand_en', 'legal_ar', 'legal_en', 'country_ar', 'country_en', 'description_ar', 'description_en', 'hero_ar', 'hero_en', 'language', 'timezone' );
	private const THEME_KEYS = array( 'primary_color', 'accent_color', 'description_en', 'phone', 'email', 'address', 'address_en', 'facebook', 'instagram', 'whatsapp', 'x', 'tiktok', 'snapchat', 'youtube', 'linkedin' );
	private const POLICY_KEYS = array( 'vat_percent', 'reservation_hours', 'reservation_refund_hours', 'reservation_deposit_type', 'reservation_deposit_value', 'privacy_retention_days' );
	private const MAIL_KEYS = array( 'ADC_MAIL_MODE', 'ADC_SMTP_HOST', 'ADC_SMTP_PORT', 'ADC_SMTP_ENCRYPTION', 'ADC_SMTP_USERNAME', 'ADC_SMTP_PASSWORD', 'ADC_MAIL_FROM', 'ADC_MAIL_FROM_NAME' );

	public static function boot(): void {
		add_action( 'admin_init', array( self::class, 'prepare_storage' ), 25 );
		add_action( 'admin_init', array( self::class, 'prepare_site' ), 30 );
		add_action( 'admin_menu', static function (): void { add_submenu_page( 'options-general.php', self::t( 'إعداد المنصة', 'Platform setup' ), self::t( 'إعداد المنصة', 'Platform setup' ), 'manage_options', 'adc-platform-setup', array( self::class, 'render' ) ); } );
		add_action( 'admin_post_adc_platform_setup', array( self::class, 'submit' ) );
		add_action( 'admin_notices', static function (): void {
			global $pagenow;
			$page = isset( $_GET['page'] ) && is_string( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
			if ( ! current_user_can( 'manage_options' ) || get_option( self::PROFILE, false ) || get_option( 'car_dealer_public_setup_version', false ) || 'options-general.php' === $pagenow || in_array( $page, array( 'adc-platform-setup', 'adc-contact', 'adc-social-channels', 'adc-branch-locations', 'adc-editorial-setup', 'adc-settings' ), true ) ) { return; }
			echo '<div class="notice notice-info"><p><a href="' . esc_url( self::url() ) . '">' . esc_html( self::t( 'ابدأ إعداد منصتك: الهوية والبريد والصفحات.', 'Set up your platform: identity, email and pages.' ) ) . '</a></p></div>';
		} );
		add_action( 'update_option_blogname', static function ( $old, $name ): void {
			$p = self::profile();
			if ( $p && ( $p['brand_ar'] ?? '' ) !== $name ) { $p['brand_ar'] = sanitize_text_field( $name ); update_option( self::PROFILE, $p, false ); }
		}, 10, 2 );
		add_action( 'updated_option', static function ( $option ): void {
			if ( ! in_array( $option, array( self::PROFILE, 'blogname' ), true ) || has_action( 'shutdown', array( self::class, 'identity_cache' ) ) ) { return; }
			add_action( 'shutdown', array( self::class, 'identity_cache' ) );
		} );
		add_shortcode( 'adc_brand_name', static fn(): string => esc_html( self::brand( Localization::language() ) ) );
		add_shortcode( 'adc_legal_name', static fn(): string => esc_html( self::legal_name( Localization::language() ) ) );
		add_shortcode( 'adc_country', static fn(): string => esc_html( self::country( Localization::language() ) ) );
		add_shortcode( 'adc_legal_contact', array( self::class, 'legal_contact' ) );
	}

	/** Prepare shared WordPress storage once, with bounded retries on restricted hosts. */
	public static function prepare_storage(): void {
		if ( ! current_user_can( 'manage_options' ) || ! Schema::is_ready() || '2' === get_option( 'adc_product_storage_prepared' ) || get_transient( 'adc_product_storage_retry' ) ) { return; }
		if ( \AutoDealership\Inventory\OnyxModelDrafts::ensure_transactional_tables() ) {
			update_option( 'adc_product_storage_prepared', '2', false );
		} else { set_transient( 'adc_product_storage_retry', 1, 5 * MINUTE_IN_SECONDS ); }
	}

	/** Runs after schema installation and theme activation, including either install order. */
	public static function prepare_site(): void {
		if ( ! current_user_can( 'manage_options' ) || 'car-dealer' !== get_template() || get_option( 'adc_db_version' ) !== Schema::VERSION || '5' === get_option( 'adc_product_site_prepared' ) ) { return; }
		$result = self::create_pages();
		if ( ! is_wp_error( $result ) ) { update_option( 'adc_product_site_prepared', '5', false ); }
	}

	public static function t( string $ar, string $en ): string { return 'en' === Localization::language() ? $en : $ar; }
	public static function url( string $section = 'identity' ): string { $target = \AutoDealership\Admin\AdminStructure::destination( 'adc-platform-setup', $section ); return add_query_arg( $target ?: array( 'page'=>'adc-platform-setup', 'section'=>$section ), admin_url( 'admin.php' ) ); }
	public static function profile(): array { return (array) get_option( self::PROFILE, array() ); }
	public static function legacy(): bool {
		if ( self::profile() || ! get_option( 'car_dealer_public_setup_version', false ) ) { return false; }
		return (bool) preg_match( '/أوتو\s+براندز|auto\s*brands/iu', (string) get_option( 'blogname', '' ) );
	}
	public static function brand( string $lang = 'ar' ): string {
		$profile = self::profile();
		$lang = 'en' === $lang ? 'en' : 'ar';
		foreach ( array( 'brand_' . $lang, 'brand_' . ( 'en' === $lang ? 'ar' : 'en' ) ) as $key ) {
			if ( isset( $profile[$key] ) && '' !== trim( (string) $profile[$key] ) ) { return wp_specialchars_decode( (string) $profile[$key], ENT_QUOTES ); }
		}
		return wp_specialchars_decode( (string) get_option( 'blogname', '' ), ENT_QUOTES );
	}
	public static function legal_name( string $lang = 'ar' ): string {
		$p = self::profile(); $lang = 'en' === $lang ? 'en' : 'ar';
		return trim( (string) ( $p['legal_' . $lang] ?? '' ) ) ?: self::brand( $lang );
	}
	public static function country( string $lang = 'ar' ): string {
		$p = self::profile(); $lang = 'en' === $lang ? 'en' : 'ar';
		foreach ( array( 'country_' . $lang, 'country_' . ( 'en' === $lang ? 'ar' : 'en' ) ) as $key ) {
			if ( isset( $p[$key] ) && '' !== trim( (string) $p[$key] ) ) { return wp_specialchars_decode( (string) $p[$key], ENT_QUOTES ); }
		}
		return '';
	}
	/** Plain text tokens only. Callers escape for their output context. */
	public static function template( string $text, string $lang ): string {
		return strtr( $text, array( '{site_name}' => self::brand( $lang ), '{legal_name}' => self::legal_name( $lang ) ) );
	}
	/** Compatibility for shipped UI translations; never apply to customer records. */
	public static function copy( string $text, string $lang ): string {
		return strtr( $text, array( '{site_name}' => self::brand( $lang ), '{legal_name}' => self::legal_name( $lang ), 'أوتو براندز' => self::brand( $lang ), 'AUTO BRANDS' => self::brand( $lang ), 'Auto Brands' => self::brand( $lang ), 'AutoBrands' => self::brand( $lang ) ) );
	}
	/** Runs after the settings transaction has committed. */
	public static function identity_cache(): void {
		CacheManager::purge_all( 'theme_identity' );
		do_action( 'adc_identity_changed' );
	}
	/** Review editable legacy page copy without touching URLs or historical records. */
	private static function identity_review(): void {
		echo '<h2>' . esc_html( self::t( 'معاينة الهوية', 'Identity preview' ) ) . '</h2><p><bdi>' . esc_html( self::brand( 'ar' ) ) . '</bdi> · <bdi dir="ltr">' . esc_html( self::brand( 'en' ) ) . '</bdi></p>';
		echo '<p>' . esc_html( self::t( 'في محرر الصفحات استخدم [adc_brand_name] أو [adc_legal_name] أو [adc_country]. في حقول نصوص الصفحة الرئيسية استخدم {site_name} أو {legal_name}. لا تتغير الروابط وبيانات التواصل والمستندات الصادرة سابقًا.', 'In the page editor use [adc_brand_name], [adc_legal_name] or [adc_country]. In homepage copy fields use {site_name} or {legal_name}. URLs, contact details and previously issued documents remain unchanged.' ) ) . '</p>';
		$pages = get_posts( array( 'post_type'=>'page', 'post_status'=>array( 'publish', 'draft', 'private' ), 'numberposts'=>200, 'orderby'=>'ID', 'order'=>'ASC' ) );
		$matches = array();
		foreach ( $pages as $page ) {
			$copy = $page->post_title . ' ' . $page->post_content . ' ' . get_post_meta( $page->ID, '_adc_title_en', true ) . ' ' . get_post_meta( $page->ID, '_adc_content_en', true );
			if ( preg_match( '/أوتو\s+براندز|auto\s*brands/iu', wp_strip_all_tags( $copy ) ) ) { $matches[] = $page; }
		}
		if ( ! $matches ) { return; }
		echo '<h3>' . esc_html( self::t( 'نصوص محفوظة تحتاج مراجعة', 'Saved copy to review' ) ) . '</h3><p>' . esc_html( self::t( 'تحتوي الصفحات التالية على اسم الهوية السابقة. راجعها من المحرر واستبدل الاسم بالرمز المناسب؛ تُحفظ المراجعات عبر نظام مراجعات ووردبريس.', 'These pages contain the previous identity name. Review them in the editor and insert the appropriate shortcode; WordPress revisions retain page edits.' ) ) . '</p><ul>';
		foreach ( $matches as $page ) { echo '<li><a href="' . esc_url( get_edit_post_link( $page->ID, 'raw' ) ) . '">' . esc_html( $page->post_title ) . '</a></li>'; }
		echo '</ul>';
	}
	public static function hero_description( string $lang ): string {
		$p = self::profile();
		if ( ! empty( $p['hero_' . $lang] ) ) { return self::template( $p['hero_' . $lang], $lang ); }
		if ( self::legacy() ) { return 'en' === $lang ? 'New vehicle sales in Al Jawharah, Jeddah, with after-sales services, polishing and window tinting. Explore your options and contact our team.' : 'مبيعات السيارات الجديدة في جدة، حي الجوهرة، وخدمات ما بعد البيع والتلميع والتظليل. استعرض الخيارات وتواصل مع فريقنا.'; }
		return 'en' === $lang ? 'Explore available vehicles, compare your options and contact our team.' : 'استعرض السيارات المتاحة وقارن الخيارات وتواصل مع فريقنا.';
	}
	private static function profile_defaults(): array {
		$appearance = (array) get_option( 'car_dealer_theme_settings', array() );
		return array( 'brand_ar'=>self::brand(), 'brand_en'=>self::brand( 'en' ), 'country_ar'=>'', 'country_en'=>'', 'description_ar'=>(string) get_option( 'blogdescription', '' ), 'description_en'=>(string) ( $appearance['description_en'] ?? '' ), 'hero_ar'=>self::hero_description( 'ar' ), 'hero_en'=>self::hero_description( 'en' ), 'language'=>'ar', 'timezone'=>wp_timezone_string() );
	}

	public static function mail_setting( string $name, string $default ): string {
		if ( ! in_array( $name, self::MAIL_KEYS, true ) ) { return $default; }
		$data = (array) get_option( self::MAIL, array() );
		if ( 'ADC_SMTP_PASSWORD' === $name ) {
			if ( empty( $data['password'] ) || ! function_exists( 'openssl_decrypt' ) ) { return $default; }
			$raw = base64_decode( $data['password'], true );
			if ( false === $raw || strlen( $raw ) < 29 ) { return ''; }
			$clear = openssl_decrypt( substr( $raw, 28 ), 'aes-256-gcm', hash( 'sha256', wp_salt( 'secure_auth' ), true ), OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ), 'adc-product-mail-v1' );
			return false === $clear ? '' : $clear;
		}
		return isset( $data[$name] ) ? (string) $data[$name] : $default;
	}

	/** All input is validated before the first write. Existing unowned settings survive. */
	public static function normalize( array $data ) {
		if ( array_diff( array_keys( $data ), array( 'profile', 'appearance', 'policy' ) ) ) { return new \WP_Error( 'adc_setup_keys', self::t( 'الملف يحتوي أقسامًا غير مسموحة.', 'The file contains unsupported sections.' ) ); }
		$clean = array();
		foreach ( array( 'profile'=>self::PROFILE_KEYS, 'appearance'=>self::THEME_KEYS, 'policy'=>self::POLICY_KEYS ) as $section=>$keys ) {
			if ( ! isset( $data[$section] ) ) { continue; }
			if ( ! is_array( $data[$section] ) || array_diff( array_keys( $data[$section] ), $keys ) ) { return new \WP_Error( 'adc_setup_keys', self::t( 'حقول الإعدادات غير صالحة.', 'Invalid settings fields.' ) ); }
			$clean[$section] = array();
			foreach ( $data[$section] as $key=>$value ) {
				if ( ! is_scalar( $value ) || strlen( (string) $value ) > 4000 ) { return new \WP_Error( 'adc_setup_value', self::t( 'قيمة إعداد غير صالحة.', 'Invalid setting value.' ) ); }
				$value = (string) $value;
				if ( in_array( $key, array( 'primary_color', 'accent_color' ), true ) ) {
					$value = sanitize_hex_color( $value ); if ( ! $value ) { return new \WP_Error( 'adc_setup_color', self::t( 'اختر لونًا صالحًا.', 'Choose a valid color.' ) ); }
				} elseif ( in_array( $key, array( 'facebook', 'instagram', 'x', 'tiktok', 'snapchat', 'youtube', 'linkedin' ), true ) ) {
					if ( $value && ! wp_http_validate_url( $value ) ) { return new \WP_Error( 'adc_setup_url', self::t( 'أدخل رابطًا عامًا صالحًا.', 'Enter a valid public URL.' ) ); } $value = esc_url_raw( $value );
				} elseif ( 'email' === $key ) {
					if ( $value && ! is_email( $value ) ) { return new \WP_Error( 'adc_setup_email', self::t( 'البريد غير صالح.', 'Invalid email address.' ) ); } $value = sanitize_email( $value );
				} elseif ( 'language' === $key ) {
					if ( ! in_array( $value, array( 'ar', 'en' ), true ) ) { return new \WP_Error( 'adc_setup_language', 'Invalid language.' ); }
				} elseif ( 'timezone' === $key ) {
					if ( ! in_array( $value, timezone_identifiers_list(), true ) && 'UTC' !== $value ) { return new \WP_Error( 'adc_setup_timezone', self::t( 'المنطقة الزمنية غير صالحة.', 'Invalid timezone.' ) ); }
				} else { $value = in_array( $key, array( 'description_ar', 'description_en', 'hero_ar', 'hero_en', 'address', 'address_en' ), true ) ? sanitize_textarea_field( $value ) : sanitize_text_field( $value ); }
				$clean[$section][$key] = $value;
			}
		}
		if ( isset( $clean['profile']['brand_ar'] ) && '' === trim( $clean['profile']['brand_ar'] ) ) { return new \WP_Error( 'adc_setup_brand', self::t( 'اسم المنشأة مطلوب.', 'Business name is required.' ) ); }
		return $clean;
	}

	public static function apply( array $data ) {
		if ( ! current_user_can( 'manage_options' ) ) { return new \WP_Error( 'adc_setup_forbidden', 'Forbidden.' ); }
		$data = self::normalize( $data ); if ( is_wp_error( $data ) ) { return $data; }
		global $wpdb;
		if ( ! \AutoDealership\Database\Transaction::begin() ) { return new \WP_Error( 'adc_setup_storage', 'Storage unavailable.' ); }
		$changed = array( self::PROFILE, 'car_dealer_theme_settings', 'blogname', 'blogdescription', 'timezone_string' );
		foreach ( array( 'vat_rate_bps', 'reservation_hours', 'reservation_refund_hours', 'reservation_deposit_type', 'reservation_deposit_value', 'privacy_retention_days' ) as $key ) { $changed[] = 'adc_' . $key; }
		// Serialize all product saves so profile merges cannot overwrite another administrator.
		$wpdb->get_results( "SELECT option_id FROM {$wpdb->options} WHERE option_name IN ('adc_product_profile','car_dealer_theme_settings','blogname') FOR UPDATE" );
		self::clear_cache( $changed );
		if ( isset( $data['policy'] ) ) {
			$result = ConfigurationService::update_section( $data['policy'], self::POLICY_KEYS );
			if ( is_wp_error( $result ) ) { $wpdb->query( 'ROLLBACK' ); self::clear_cache( $changed ); return $result; }
		}
		if ( isset( $data['profile'] ) ) {
			$p = array_replace( self::profile(), $data['profile'] ); update_option( self::PROFILE, $p, false );
			if ( isset( $p['brand_ar'] ) ) { update_option( 'blogname', $p['brand_ar'] ); }
			if ( isset( $p['description_ar'] ) ) { update_option( 'blogdescription', $p['description_ar'] ); }
			if ( isset( $p['timezone'] ) ) { update_option( 'timezone_string', $p['timezone'] ); }
			if ( isset( $data['profile']['description_en'] ) ) { $data['appearance']['description_en'] = $data['profile']['description_en']; }
		}
		if ( isset( $data['appearance'] ) ) { update_option( 'car_dealer_theme_settings', array_replace( (array) get_option( 'car_dealer_theme_settings', array() ), $data['appearance'] ), false ); }
		$ok = ! $wpdb->last_error && AuditLog::record( 'platform.settings_updated', 'settings', 0, 'Product settings saved', null, array( 'sections'=>array_keys( $data ) ) );
		if ( ! $ok || false === $wpdb->query( 'COMMIT' ) ) { $wpdb->query( 'ROLLBACK' ); self::clear_cache( $changed ); return new \WP_Error( 'adc_setup_storage', self::t( 'تعذر حفظ الإعدادات.', 'Could not save settings.' ) ); }
		return true;
	}
	private static function clear_cache( array $keys ): void { foreach ( $keys as $key ) { wp_cache_delete( $key, 'options' ); } ConfigurationService::clear_option_cache(); }

	public static function export(): array {
		$policy = array();
		foreach ( self::POLICY_KEYS as $key ) { $policy[$key] = 'vat_percent' === $key ? ( (int) get_option( 'adc_vat_rate_bps', 1500 ) / 100 ) : get_option( 'adc_' . $key, in_array( $key, array( 'reservation_deposit_type' ), true ) ? 'none' : ( 'reservation_hours' === $key ? 24 : ( 'reservation_refund_hours' === $key ? 72 : 0 ) ) ); }
		return array( 'product'=>'auto-dealership', 'format'=>1, 'settings'=>array( 'profile'=>array_intersect_key( array_replace( self::profile_defaults(), self::profile() ), array_flip( self::PROFILE_KEYS ) ), 'appearance'=>array_intersect_key( (array) get_option( 'car_dealer_theme_settings', array() ), array_flip( self::THEME_KEYS ) ), 'policy'=>$policy ) );
	}
	public static function import_preview( string $json ) {
		if ( strlen( $json ) > 262144 ) { return new \WP_Error( 'adc_setup_size', 'Maximum file size is 256 KB.' ); }
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) || array_diff( array_keys( $data ), array( 'product', 'format', 'settings' ) ) || 'auto-dealership' !== ( $data['product'] ?? '' ) || 1 !== ( $data['format'] ?? 0 ) || ! is_array( $data['settings'] ?? null ) ) { return new \WP_Error( 'adc_setup_format', self::t( 'صيغة الملف غير مدعومة.', 'Unsupported settings file.' ) ); }
		return self::normalize( $data['settings'] );
	}

	public static function blueprints(): array { return json_decode( (string) file_get_contents( ADC_PATH . 'resources/site-defaults.json' ), true )['pages'] ?? array(); }
	public static function contact_address( string $language = '' ): string {
		$settings = (array) get_option( 'car_dealer_theme_settings', array() );
		$address = (string) ( $settings['address'] ?? '' );
		if ( 'en' === ( $language ?: Localization::language() ) ) {
			$address = trim( (string) ( $settings['address_en'] ?? '' ) ) ?: ( preg_match( '/\p{Arabic}/u', $address ) ? '' : $address );
		}
		return trim( $address );
	}
	public static function legal_contact(): string {
		$settings = (array) get_option( 'car_dealer_theme_settings', array() );
		$parts = array( esc_html( self::legal_name( Localization::language() ) ) );
		$address = self::contact_address();
		if ( '' !== trim( $address ) ) { $parts[] = esc_html( $address ); }
		$email = sanitize_email( (string) ( $settings['email'] ?? '' ) );
		if ( $email ) { $parts[] = '<a href="' . esc_url( 'mailto:' . $email ) . '">' . esc_html( $email ) . '</a>'; }
		$phone = (string) ( $settings['phone'] ?? '' ); $dial = preg_replace( '/[^+0-9]/', '', $phone );
		if ( $dial ) { $parts[] = '<a href="' . esc_url( 'tel:' . $dial ) . '" dir="ltr">' . esc_html( $phone ) . '</a>'; }
		return '<p>' . implode( ' · ', $parts ) . '</p><p>' . esc_html( self::t( 'يرجى عدم إرسال كلمات المرور أو بيانات الدفع الكاملة عبر البريد أو نماذج التواصل.', 'Please do not send passwords or complete payment details by email or contact forms.' ) ) . '</p>';
	}
	/** Replace only recognizable shipped defaults, never arbitrary editorial text. */
	private static function upgrade_legal_page( \WP_Post $existing, array $page ) {
		$old = $existing->post_content;
		$replace = in_array( trim( $old ), array( '', '<p>يرجى استكمال هذه السياسة ومراجعتها واعتمادها قبل النشر.</p>', '<p>Complete, review and approve this policy before publication.</p>' ), true );
		if ( ! $replace && 'privacy-policy' === $page['slug'] ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-privacy-policy-content.php';
			foreach ( array_unique( array( get_locale(), 'en_US', 'ar' ) ) as $locale ) {
				$switched = switch_to_locale( $locale );
				try { if ( trim( $old ) === trim( \WP_Privacy_Policy_Content::get_default_content() ) ) { $replace = true; } }
				finally { if ( $switched ) { restore_previous_locale(); } }
			}
		}
		if ( $replace ) {
			$result = wp_update_post( wp_slash( array( 'ID'=>$existing->ID, 'post_title'=>$page['title'], 'post_content'=>$page['content'] ) ), true );
			if ( is_wp_error( $result ) ) { return $result; }
		}
		$source_matches = $replace || $old === $page['content'];
		foreach ( array( 'title', 'content' ) as $field ) {
			$key = '_adc_' . $field . '_en'; $english = (string) get_post_meta( $existing->ID, $key, true );
			$placeholder = in_array( trim( $english ), array( '', '<p>Complete, review and approve this policy before publication.</p>' ), true );
			if ( $source_matches && ( $placeholder || ( 'title' === $field && $replace ) ) ) {
				update_post_meta( $existing->ID, $key, wp_slash( $page[$field . '_en'] ) );
				$source = 'title' === $field ? get_post( $existing->ID )->post_title : $page['content'];
				update_post_meta( $existing->ID, $key . '_source_hash', hash( 'sha256', $source ) );
			}
		}
		$template = (string) get_post_meta( $existing->ID, '_wp_page_template', true );
		if ( in_array( $template, array( '', 'default' ), true ) && isset( wp_get_theme()->get_page_templates()['page-legal.php'] ) ) { update_post_meta( $existing->ID, '_wp_page_template', 'page-legal.php' ); }
		return true;
	}
	public static function create_pages() {
		if ( ! current_user_can( 'manage_options' ) ) { return new \WP_Error( 'adc_setup_forbidden', 'Forbidden.' ); }
		global $wpdb; $lock = 'adc_product_pages_' . md5( DB_NAME . $wpdb->prefix );
		if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock ) ) ) { return new \WP_Error( 'adc_setup_busy', 'Please try again.' ); }
		try {
			$ids = array();
			foreach ( self::blueprints() as $page ) {
				$existing = get_page_by_path( $page['slug'], OBJECT, 'page' );
				if ( $existing ) {
					if ( 'about' === $page['slug'] ) {
						$upgrade = AboutPage::upgrade($existing, $page); if (is_wp_error($upgrade)) { return $upgrade; }
						$template = (string)get_post_meta($existing->ID,'_wp_page_template',true);
						if (str_contains(get_post($existing->ID)->post_content,'adc-about-page') && in_array($template,array('','default'),true) && isset(wp_get_theme()->get_page_templates()['page-about.php'])) { update_post_meta($existing->ID,'_wp_page_template','page-about.php'); }
					}
					if ( ! empty( $page['legal'] ) ) { $upgrade = self::upgrade_legal_page( $existing, $page ); if ( is_wp_error( $upgrade ) ) { return $upgrade; } }
					if ( ! empty( $page['legal'] ) && 'draft' === $existing->post_status ) {
						$published = wp_update_post( array( 'ID'=>$existing->ID, 'post_status'=>'publish' ), true );
						if ( is_wp_error( $published ) ) { return $published; }
					}
					$ids[$page['slug']] = $existing->ID; continue;
				}
				$id = wp_insert_post( wp_slash( array( 'post_type'=>'page', 'post_name'=>$page['slug'], 'post_title'=>$page['title'], 'post_content'=>$page['content'], 'post_status'=>'publish', 'post_author'=>get_current_user_id(), 'comment_status'=>'closed' ) ), true );
				if ( is_wp_error( $id ) ) { return $id; }
				if ('about' === $page['slug'] && isset(wp_get_theme()->get_page_templates()['page-about.php'])) { update_post_meta($id,'_wp_page_template','page-about.php'); }
				if ( ! empty( $page['legal'] ) && isset( wp_get_theme()->get_page_templates()['page-legal.php'] ) ) { update_post_meta( $id, '_wp_page_template', 'page-legal.php' ); }
				foreach ( array( 'title', 'content' ) as $field ) { update_post_meta( $id, '_adc_' . $field . '_en', wp_slash( $page[$field . '_en'] ) ); update_post_meta( $id, '_adc_' . $field . '_en_source_hash', hash( 'sha256', $page[$field] ) ); }
				$ids[$page['slug']] = $id;
			}
			$locations = get_theme_mod( 'nav_menu_locations', array() );
			foreach ( array( 'primary'=>array( 'cars', 'about', 'finance', 'faq', 'buying-guide', 'contact' ), 'footer'=>array( 'about', 'contact', 'faq', 'buying-guide', 'privacy-policy', 'terms', 'reservation-policy', 'cookie-policy' ) ) as $slot=>$slugs ) {
				$assigned = ! empty( $locations[$slot] ) ? wp_get_nav_menu_object( $locations[$slot] ) : false;
				$legacy_primary = false;
				if ( $assigned && 'primary' === $slot && self::brand() . ' — primary' === $assigned->name ) {
					$old_items = wp_get_nav_menu_items( $assigned->term_id ) ?: array();
					$old_slugs = array();
					foreach ( $old_items as $old_item ) {
						$post = get_post( (int) $old_item->object_id );
						$old_slugs[] = 'post_type' === $old_item->type && 'page' === $old_item->object && ! $old_item->menu_item_parent && $post && in_array( $old_item->post_title, array( '', $post->post_title ), true ) ? $post->post_name : '';
					}
					$legacy_primary = array( 'about', 'contact', 'finance', 'comparison' ) === $old_slugs;
					if ( $legacy_primary ) { $assigned = false; }
				}
				if ( $assigned && 'footer' !== $slot ) { continue; }
				if ( $assigned ) { $slugs = array( 'privacy-policy', 'terms', 'reservation-policy', 'cookie-policy' ); }
				$name = self::brand() . ' — ' . $slot . ( $legacy_primary ? ' v2' : '' );
				$existing_menu = $assigned ?: wp_get_nav_menu_object( $name );
				$menu = $existing_menu ? $existing_menu->term_id : wp_create_nav_menu( $name ); if ( is_wp_error( $menu ) ) { return $menu; }
				$items = wp_get_nav_menu_items( $menu ) ?: array();
				$linked = array_map( static fn( $item ): int => 'post_type' === $item->type && 'page' === $item->object ? (int) $item->object_id : 0, $items );
				if ( 'primary' === $slot && ! array_filter( $items, static fn( $item ): bool => 'post_type_archive' === $item->type && 'car' === $item->object ) ) {
					$item = wp_update_nav_menu_item( $menu, 0, array( 'menu-item-title'=>'السيارات', 'menu-item-object'=>'car', 'menu-item-type'=>'post_type_archive', 'menu-item-status'=>'publish', 'menu-item-position'=>1 ) );
					if ( is_wp_error( $item ) ) { return $item; }
				}
				foreach ( $slugs as $slug ) { if ( isset( $ids[$slug] ) && ! in_array( (int) $ids[$slug], $linked, true ) && 'publish' === get_post_status( $ids[$slug] ) ) { $item = wp_update_nav_menu_item( $menu, 0, array( 'menu-item-object-id'=>$ids[$slug], 'menu-item-object'=>'page', 'menu-item-type'=>'post_type', 'menu-item-status'=>'publish' ) ); if ( is_wp_error( $item ) ) { return $item; } } }
				$locations[$slot] = $menu;
			}
			set_theme_mod( 'nav_menu_locations', $locations );
			if ( ! get_option( 'wp_page_for_privacy_policy' ) && isset( $ids['privacy-policy'] ) ) { update_option( 'wp_page_for_privacy_policy', $ids['privacy-policy'] ); }
			flush_rewrite_rules( false );
			AuditLog::record( 'platform.pages_prepared', 'settings', 0, 'Missing neutral pages created; existing pages preserved', null, array( 'pages'=>array_keys( $ids ) ) );
			return $ids;
		} finally { $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) ); }
	}

	public static function readiness(): array {
		$mail = function_exists( 'adc_product_mail_config' ) ? adc_product_mail_config() : array();
		$local = in_array( wp_get_environment_type(), array( 'local', 'development' ), true );
		$pages = true; $legal = true;
		foreach ( self::blueprints() as $row ) { $p = get_page_by_path( $row['slug'], OBJECT, 'page' ); if ( ! $p || 'publish' !== $p->post_status ) { if ( ! empty( $row['legal'] ) ) { $legal = false; } else { $pages = false; } } }
		$theme = wp_get_theme();
		return array(
			self::t( 'هوية المنشأة', 'Business identity' )=>! empty( self::profile()['brand_ar'] ) || self::legacy(),
			self::t( 'الثيم المتوافق وإصداره', 'Matching theme version' )=>'car-dealer' === get_template() && ADC_VERSION === $theme->get( 'Version' ),
			self::t( 'مخطط قاعدة البيانات', 'Database schema' )=>Schema::is_ready(),
			self::t( 'فرع تشغيلي نشط', 'Active operating branch' )=>self::active_branch_ready(),
			self::t( 'الأدوار التشغيلية الأساسية', 'Core operational roles' )=>self::core_roles_ready(),
			self::t( 'إعداد توزيع الفرص', 'Lead assignment configuration' )=>self::lead_configuration_ready(),
			self::t( 'جدولة المهام الحرجة', 'Critical scheduled jobs' )=>self::scheduled_jobs_ready(),
			self::t( 'دعم استيراد المخزون الآمن', 'Transactional inventory storage' )=>\AutoDealership\Inventory\OnyxModelDrafts::transactional_tables(),
			self::t( 'اتصال HTTPS', 'HTTPS' )=>'https' === wp_parse_url( home_url(), PHP_URL_SCHEME ),
			self::t( 'عنوان عام آمن لروابط تأكيد البريد واستعادة الحساب', 'Public HTTPS address for verification and account recovery links' )=>\AutoDealership\Accounts\EmailVerification::public_link_origin(),
			self::t( 'SMTP حقيقي مهيّأ', 'Real SMTP configured' )=>'smtp' === ( $mail['mode'] ?? '' ) && ! empty( $mail['valid'] ),
			self::t( 'الصفحات الأساسية', 'Essential pages' )=>$pages,
			self::t( 'الصفحات القانونية منشورة', 'Legal pages published' )=>$legal,
			self::t( 'تشغيل عامل البريد مرصود ولا توجد رسائل قديمة معلقة', 'Mail worker execution observed without old held messages' )=>self::job_readiness(),
			self::t( 'بيانات التواصل', 'Contact details' )=>! empty( get_option( 'car_dealer_theme_settings', array() )['email'] ),
			self::t( 'بيئة إنتاج', 'Production environment' )=>! $local && 'production' === wp_get_environment_type(),
		);
	}

	private static function active_branch_ready(): bool {
		if ( ! Schema::is_ready() ) { return false; }
		global $wpdb;
		return (bool) $wpdb->get_var( 'SELECT id FROM ' . Schema::table( 'branches' ) . ' WHERE active=1 ORDER BY id ASC LIMIT 1' );
	}

	private static function core_roles_ready(): bool {
		$requirements = array(
			'dealership_sales' => array( 'read', 'adc_view_own_leads', 'adc_manage_own_leads' ),
			'dealership_sales_manager' => array( 'read', 'adc_view_branch_leads', 'adc_manage_branch_leads' ),
			'dealership_general_manager' => array( 'read', 'adc_view_branch_leads', 'adc_view_inventory', 'adc_view_reports' ),
		);
		foreach ( $requirements as $slug => $caps ) {
			$role = get_role( $slug );
			if ( ! $role ) { return false; }
			foreach ( $caps as $cap ) { if ( empty( $role->capabilities[ $cap ] ) ) { return false; } }
		}
		return true;
	}

	private static function lead_configuration_ready(): bool {
		$mode = sanitize_key( (string) get_option( 'adc_lead_assignment_mode', 'manual' ) );
		if ( ! in_array( $mode, array( 'manual', 'manager', 'round_robin' ), true ) ) { return false; }
		$archive_days = absint( get_option( 'adc_lead_archive_days', 30 ) );
		$stale_days = absint( get_option( 'adc_lead_stale_days', 7 ) );
		if ( 0 === $archive_days || 0 === $stale_days ) { return false; }
		$default_branch = absint( get_option( 'adc_default_branch_id', 0 ) );
		if ( ! $default_branch ) { return self::active_branch_ready(); }
		if ( ! Schema::is_ready() ) { return false; }
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Schema::table( 'branches' ) . ' WHERE id=%d AND active=1 LIMIT 1', $default_branch ) );
	}

	private static function scheduled_jobs_ready(): bool {
		$hooks = array( 'adc_process_outbox', 'adc_scan_followups', 'adc_affiliate_commission_reconciliation', 'adc_archive_closed_leads', 'adc_expire_reservations', 'adc_prune_request_limits' );
		foreach ( $hooks as $hook ) { if ( ! wp_next_scheduled( $hook ) ) { return false; } }
		return true;
	}

	private static function render_legal_pages(): void {
		echo '<h2>' . esc_html( self::t( 'صفحات السياسات القانونية', 'Legal policy pages' ) ) . '</h2><p>' . esc_html( self::t( 'تُنشر تلقائيًا وتُضاف إلى قائمة التذييل. يمكنك تعديل النصوص العربية والإنجليزية من محرر الصفحة.', 'Published automatically and added to the footer menu. Edit Arabic and English text in the page editor.' ) ) . '</p><table class="widefat striped"><thead><tr><th>' . esc_html( self::t( 'الصفحة', 'Page' ) ) . '</th><th>' . esc_html( self::t( 'الحالة', 'Status' ) ) . '</th><th>' . esc_html( self::t( 'الإجراءات', 'Actions' ) ) . '</th></tr></thead><tbody>';
		foreach ( self::blueprints() as $blueprint ) {
			if ( empty( $blueprint['legal'] ) ) { continue; }
			$page = get_page_by_path( $blueprint['slug'], OBJECT, 'page' );
			echo '<tr><td>' . esc_html( self::t( $blueprint['title'], $blueprint['title_en'] ) ) . '</td><td>' . esc_html( $page ? ( get_post_status_object( $page->post_status )->label ?? $page->post_status ) : self::t( 'غير موجودة', 'Missing' ) ) . '</td><td>';
			if ( $page && current_user_can( 'edit_post', $page->ID ) ) { echo '<a class="button" href="' . esc_url( get_edit_post_link( $page->ID, 'raw' ) ) . '">' . esc_html( self::t( 'تعديل الصفحة', 'Edit page' ) ) . '</a> '; }
			if ( $page && 'publish' === $page->post_status ) { echo '<a class="button" href="' . esc_url( get_permalink( $page ) ) . '" target="_blank" rel="noopener">' . esc_html( self::t( 'عرض الصفحة', 'View page' ) ) . '</a>'; }
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	public static function save_mail( array $input ) {
		if ( ! current_user_can( 'manage_options' ) ) { return new \WP_Error( 'adc_setup_forbidden', 'Forbidden.' ); }
		$data = (array) get_option( self::MAIL, array() );
		if ( array_diff( array_keys( $input ), self::MAIL_KEYS ) ) { return new \WP_Error( 'adc_setup_mail', 'Unsupported mail fields.' ); }
		$mode = (string) ( $input['ADC_MAIL_MODE'] ?? 'disabled' );
		if ( ! in_array( $mode, array( 'disabled', 'smtp', 'mailpit' ), true ) || ( 'mailpit' === $mode && ! in_array( wp_get_environment_type(), array( 'local', 'development' ), true ) ) ) { return new \WP_Error( 'adc_setup_mail', 'Invalid mail mode.' ); }
		foreach ( self::MAIL_KEYS as $key ) {
			if ( 'ADC_SMTP_PASSWORD' === $key ) { continue; }
			$value = $input[$key] ?? ''; if ( ! is_scalar( $value ) || strlen( (string) $value ) > 255 ) { return new \WP_Error( 'adc_setup_mail', 'Invalid mail value.' ); }
			$data[$key] = sanitize_text_field( (string) $value );
		}
		$password = $input['ADC_SMTP_PASSWORD'] ?? ''; if ( ! is_string( $password ) || strlen( $password ) > 4096 ) { return new \WP_Error( 'adc_setup_mail', 'Invalid password.' ); }
		// The first dashboard save adopts the working server secret without exposing it in HTML.
		if(''===$password && empty($data['password']) && !get_option('adc_product_mail_dashboard',false)) { $password=adc_product_mail_setting('ADC_SMTP_PASSWORD'); }
		if('smtp'===$mode && 'smtp.gmail.com'===strtolower($data['ADC_SMTP_HOST'])) {
			if(!in_array($data['ADC_SMTP_PORT'].':'.$data['ADC_SMTP_ENCRYPTION'],array('587:tls','465:ssl'),true)) { return new \WP_Error('adc_setup_mail',self::t('لبريد Gmail استخدم المنفذ 587 مع STARTTLS، أو 465 مع TLS / SSL.','For Gmail use port 587 with STARTTLS, or 465 with TLS / SSL.')); }
			if(strtolower($data['ADC_SMTP_USERNAME'])!==strtolower($data['ADC_MAIL_FROM'])) { return new \WP_Error('adc_setup_mail',self::t('اجعل بريد المرسل هو عنوان Gmail المستخدم لتسجيل الدخول.','Use the Gmail login address as the sender email.')); }
			$password=preg_replace('/\s+/','',$password);
		}
		if ( '' !== $password ) {
			if ( ! function_exists( 'openssl_encrypt' ) ) { return new \WP_Error( 'adc_setup_crypto', 'OpenSSL is required.' ); }
			$iv = random_bytes( 12 ); $tag = ''; $encrypted = openssl_encrypt( $password, 'aes-256-gcm', hash( 'sha256', wp_salt( 'secure_auth' ), true ), OPENSSL_RAW_DATA, $iv, $tag, 'adc-product-mail-v1' );
			if ( false === $encrypted ) { return new \WP_Error( 'adc_setup_crypto', 'Encryption failed.' ); }
			$data['password'] = base64_encode( $iv . $tag . $encrypted );
		}
		if ( 'smtp' === $mode && ( ! is_email( $data['ADC_MAIL_FROM'] ) || ! preg_match( '/\A[a-zA-Z0-9.-]+\z/', $data['ADC_SMTP_HOST'] ) || ! in_array( $data['ADC_SMTP_ENCRYPTION'], array( 'tls', 'ssl' ), true ) || ! ctype_digit( $data['ADC_SMTP_PORT'] ) || (int) $data['ADC_SMTP_PORT'] < 1 || (int) $data['ADC_SMTP_PORT'] > 65535 || ! $data['ADC_SMTP_USERNAME'] || empty( $data['password'] ) ) ) { return new \WP_Error( 'adc_setup_mail', self::t( 'أكمل إعدادات SMTP الصحيحة.', 'Complete valid SMTP settings.' ) ); }
		$old = get_option( self::MAIL, null ); update_option( self::MAIL, $data, false );
		if ( get_option( self::MAIL ) !== $data || ! AuditLog::record( 'platform.mail_configured', 'settings', 0, 'Mail settings updated; credentials excluded from audit', null, array( 'mode'=>$mode ) ) ) { null === $old ? delete_option( self::MAIL ) : update_option( self::MAIL, $old, false ); return new \WP_Error( 'adc_setup_storage', 'Could not save.' ); }
		update_option('adc_product_mail_dashboard',true,false);
		return true;
	}
	private static function job_readiness(): bool { $health=\AutoDealership\Operations\JobRuntime::status();return $health['worker_observed'] && 'browser'!==$health['worker_source'] && !$health['held_mail'] && !$health['failed_jobs']; }
	public static function mail_status(): void {
		$last=(array)get_option('adc_product_mail_result',array());
		$messages=array(
			'authentication'=>array('رفض مزود البريد بيانات الدخول. تحقق من عنوان Gmail وكلمة مرور التطبيق.','The provider rejected authentication. Check the Gmail address and app password.'),
			'connection'=>array('تعذر الاتصال بخادم البريد. تحقق من الخادم والمنفذ وسياسة اتصالات الاستضافة.','Could not connect to SMTP. Check the host, port and hosting connection policy.'),
			'tls'=>array('تعذر إنشاء اتصال مشفر. تحقق من توافق المنفذ مع نوع التشفير.','Encrypted connection failed. Check the port and encryption combination.'),
			'configuration'=>array('الإرسال متوقف أو إعداداته غير مكتملة.','Mail is disabled or configuration is incomplete.'),
			'limit'=>array('تم بلوغ أحد حدود الإرسال لدى مزود البريد.','The provider sending limit was reached.'),
			'other'=>array('لم يقبل مزود البريد الرسالة. تحقق من الإعدادات ثم أعد الاختبار.','The provider did not accept the message. Check settings and test again.')
		);
		$config = function_exists( 'adc_product_mail_config' ) ? adc_product_mail_config() : array();
		$valid = 'mailpit' === ( $config['mode'] ?? '' ) ? ! empty( $config['local'] ) : ! empty( $config['valid'] );
		if ( ! $valid ) { echo '<div id="adc-mail-configuration-notice" class="notice notice-error inline"><p>' . esc_html( 'البريد متوقف: يجب ضبط إعدادات SMTP لهذه البيئة. / Mail is disabled: configure SMTP for this environment.' ) . '</p></div>'; }
		echo '<div class="notice notice-info inline"><p>'.esc_html(get_option('adc_product_mail_dashboard',false)?self::t('مصدر الإعدادات الفعّال: إعداد المنصة.','Active settings source: Platform setup.'):self::t('تُستخدم إعدادات الخادم حتى تحفظ إعدادات هذه الشاشة.','Server settings apply until you save this screen.')).'</p><p>'.esc_html(''!==self::mail_setting('ADC_SMTP_PASSWORD','')?self::t('كلمة مرور محفوظة؛ اترك الحقل فارغًا للاحتفاظ بها.','A password is saved; leave the field blank to keep it.'):self::t('لم تُحفظ كلمة مرور في إعداد المنصة بعد.','No password has been saved in Platform setup yet.')).'</p>';
		if(isset($last['status'])) { echo '<p>'.esc_html('accepted'===$last['status']?self::t('آخر إرسال: قبله خادم البريد. هذا لا يؤكد وصوله إلى صندوق الوارد.','Last send: accepted by the mail server. This does not confirm inbox delivery.'):self::t(...($messages[$last['kind']??'other']??$messages['other']))).' '.esc_html(isset($last['time'])?get_date_from_gmt($last['time'],'Y-m-d H:i'):'').'</p>'; }
		echo '</div>';
	}
	public static function send_mail_test(string $to,string $kind='smtp',string $language=''): bool {
		if(!current_user_can('manage_options') || !is_email($to) || !in_array($kind,array('smtp','newsletter'),true)) { return false; }
		if(''!==$language && !in_array($language,array('ar','en'),true)){return false;}
		$lang=$language?:Localization::language();$t=static fn(string $ar,string $en):string=>'en'===$lang?$en:$ar;
		if('smtp'===$kind) { return wp_mail($to,self::brand().' | SMTP test',$t('هذه رسالة اختبار لإعداد البريد من لوحة الإدارة.','This is an administrator-requested mail configuration test.')); }
		$local=in_array(wp_get_environment_type(),array('local','development'),true);$origin=$local?$t('اللوكل','Local site'):$t('الاستضافة','Hosted site');
		$title=$t('اختبار النشرة البريدية','Newsletter delivery test').' — '.$origin;
		$body='<p>'.esc_html($t('مرحبًا بك في نشرة ','Welcome to the newsletter of ').self::brand($lang)).'</p><p>'.esc_html($t('هذه رسالة اختبار للتحقق من عرض النشرة البريدية وإرسالها من الموقع.','This test checks the newsletter layout and delivery from this website.')).'</p><p>'.esc_html($t('أُرسلت هذه النسخة إلى بريد الاختبار المحدد فقط، دون إرسال حملة إلى المشتركين أو تغيير تفضيلات اشتراكك.','This copy was sent only to the specified test address. No subscriber campaign was sent and your subscription preferences were not changed.')).'</p>';
		$html=\AutoDealership\Accounts\BrandedMail::render($title,$body,$t('زيارة الموقع','Visit website'),home_url('/'),esc_html($t('رسالة اختبار بطلب إدارة الموقع.','Test message requested by the site administrator.')),$lang);
		return \AutoDealership\Accounts\BrandedMail::send($to,$title,$html);
	}

	public static function submit(): void {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden', '', array( 'response'=>403 ) ); }
		check_admin_referer( 'adc_platform_setup' );
		$operation = sanitize_key( $_POST['operation'] ?? '' ); $section = sanitize_key( $_POST['section'] ?? 'identity' );
		if ( ! in_array( $section, self::SECTIONS, true ) ) { $section = 'identity'; }
		$result = true;
		if ( 'export' === $operation ) { nocache_headers(); header( 'Content-Type: application/json; charset=utf-8' ); header( 'Content-Disposition: attachment; filename="dealership-settings.json"' ); echo wp_json_encode( self::export(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ); exit; }
		if ( 'preview' === $operation ) {
			$file = $_FILES['settings_file'] ?? array();
			$result = empty( $file['error'] ) && ! empty( $file['tmp_name'] ) && is_uploaded_file( $file['tmp_name'] ) && (int) $file['size'] <= 262144 ? self::import_preview( (string) file_get_contents( $file['tmp_name'] ) ) : new \WP_Error( 'adc_setup_upload', self::t( 'اختر ملف JSON أصغر من 256 كيلوبايت.', 'Choose a JSON file smaller than 256 KB.' ) );
			if ( ! is_wp_error( $result ) ) { set_transient( 'adc_setup_preview_' . get_current_user_id(), $result, 10 * MINUTE_IN_SECONDS ); wp_safe_redirect( add_query_arg( 'preview', 1, self::url( 'readiness' ) ) ); exit; }
		} elseif ( 'import' === $operation ) {
			$data = get_transient( 'adc_setup_preview_' . get_current_user_id() );
			$preview_hash = isset( $_POST['preview_hash'] ) && is_string( $_POST['preview_hash'] ) ? $_POST['preview_hash'] : '';
			$result = is_array( $data ) && hash_equals( hash( 'sha256', wp_json_encode( $data ) ), $preview_hash ) ? self::apply( $data ) : new \WP_Error( 'adc_setup_expired', self::t( 'انتهت المعاينة أو تغيرت. ارفع الملف وراجعه مجددًا.', 'Preview expired or changed. Upload and review again.' ) );
			if ( ! is_wp_error( $result ) ) { delete_transient( 'adc_setup_preview_' . get_current_user_id() ); }
		} elseif ( 'pages' === $operation ) { $result = self::create_pages();
		} elseif ( 'mail_test' === $operation ) {
			$to = sanitize_email( wp_unslash( $_POST['test_email'] ?? '' ) );
			$kind=isset($_POST['test_kind']) && is_string($_POST['test_kind'])?sanitize_key($_POST['test_kind']):'smtp';
			$language=isset($_POST['test_language']) && is_string($_POST['test_language'])?sanitize_key($_POST['test_language']):'';
			$result = self::send_mail_test($to,$kind,$language) ? true : new \WP_Error( 'adc_setup_test', self::t( 'تعذر إرسال رسالة الاختبار.', 'Test mail could not be sent.' ) );
		} elseif ( 'save' === $operation ) {
			$input = wp_unslash( $_POST['settings'] ?? array() );
			if ( ! is_array( $input ) ) { $input = array(); }
			$invalid_amount = false;
			if ( 'policy' === $section && isset( $input['reservation_deposit_value'] ) ) {
				$amount = \AutoDealership\Pricing\Money::from_sar( $input['reservation_deposit_value'] );
				$invalid_amount = null === $amount;
				$input['reservation_deposit_value'] = $amount;
			}
			$result = $invalid_amount ? new \WP_Error( 'adc_setup_amount', self::t( 'أدخل مبلغًا أو نسبة صحيحة بحد أقصى منزلتين عشريتين.', 'Enter a valid amount or percentage with up to two decimal places.' ) ) : ( 'mail' === $section ? self::save_mail( $input ) : self::apply( array( 'identity' === $section ? 'profile' : ( 'policy' === $section ? 'policy' : 'appearance' )=>$input ) ) );
		} else { $result = new \WP_Error( 'adc_setup_operation', 'Invalid operation.' ); }
		if ( is_wp_error( $result ) ) { set_transient( 'adc_setup_error_' . get_current_user_id(), $result->get_error_message(), MINUTE_IN_SECONDS ); }
		else { set_transient( 'adc_setup_success_' . get_current_user_id(), true, MINUTE_IN_SECONDS ); }
		wp_safe_redirect( self::url( $section ) ); exit;
	}

	private static function form( string $section, string $operation = 'save', bool $upload = false ): void {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $upload ? ' enctype="multipart/form-data"' : '' ) . '><input type="hidden" name="action" value="adc_platform_setup"><input type="hidden" name="operation" value="' . esc_attr( $operation ) . '"><input type="hidden" name="section" value="' . esc_attr( $section ) . '">'; wp_nonce_field( 'adc_platform_setup' );
	}
	private static function field( string $key, string $label, string $value, string $type = 'text', array $choices = array() ): void {
		if ( $choices ) {
			echo '<tr><th><label for="setup-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><select id="setup-' . esc_attr( $key ) . '" name="settings[' . esc_attr( $key ) . ']">';
			foreach ( $choices as $choice=>$text ) { echo '<option value="' . esc_attr( (string) $choice ) . '"' . selected( (string) $choice, $value, false ) . '>' . esc_html( $text ) . '</option>'; }
			echo '</select></td></tr>'; return;
		}
		echo '<tr><th><label for="setup-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><input class="regular-text" id="setup-' . esc_attr( $key ) . '" name="settings[' . esc_attr( $key ) . ']" type="' . esc_attr( $type ) . '"' . ( str_ends_with( $key, '_en' ) || in_array( $key, array( 'phone', 'email' ), true ) ? ' dir="ltr"' : '' ) . ' value="' . esc_attr( $value ) . '"' . ( 'password' === $type ? ' autocomplete="new-password"' : '' ) . '></td></tr>';
	}
    public static function render_contact(): void { self::render(); }

    /** Provisioning is distinct from draft creation, but shares the pages screen. */
    public static function render_page_tools(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $error = get_transient( 'adc_setup_error_' . get_current_user_id() );
        if ( $error ) { delete_transient( 'adc_setup_error_' . get_current_user_id() ); echo '<div class="notice notice-error"><p>' . esc_html( $error ) . '</p></div>'; }
        if ( get_transient( 'adc_setup_success_' . get_current_user_id() ) ) { delete_transient( 'adc_setup_success_' . get_current_user_id() ); echo '<div class="notice notice-success"><p>' . esc_html( self::t( 'اكتمل إعداد الصفحات والقوائم.', 'Pages and menus prepared.' ) ) . '</p></div>'; }
        echo '<details class="adc-setup-tools"><summary>' . esc_html( self::t( 'إعداد القوائم ونشر صفحات السياسات', 'Prepare menus and publish policy pages' ) ) . '</summary><p>' . esc_html( self::t( 'عملية مستقلة عن إنشاء المسودات: تجهّز صفحات المنصة والقوائم وتنشر السياسات وتراجع صيغها القديمة المدعومة. راجع النصوص قبل الاستخدام؛ يبقى المحتوى المخصص محفوظًا.', 'Separate from draft creation: prepares platform pages and menus, publishes policies and updates supported legacy policy copy. Review text before use; custom page content is preserved.' ) ) . '</p>';
        self::form( 'pages', 'pages' ); submit_button( self::t( 'تجهيز الصفحات والقوائم والسياسات', 'Prepare pages, menus and policies' ), 'secondary' );
        echo '</form>'; self::render_legal_pages(); echo '</details>';
    }

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html( self::t( 'غير مسموح.', 'Access denied.' ) ), '', array( 'response'=>403 ) ); }
		$section = sanitize_key( $_GET['section'] ?? 'identity' ); if ( ! in_array( $section, self::SECTIONS, true ) ) { $section = 'identity'; }
		$contact = 'adc-contact' === ( $_GET['page'] ?? '' );
		if ( $contact ) { $section = 'appearance'; }
		$labels = array( 'identity'=>self::t( 'الهوية واللغة', 'Identity and language' ), 'mail'=>self::t( 'البريد', 'Email' ), 'readiness'=>self::t( 'الجاهزية ونقل الإعدادات', 'Readiness and settings transfer' ) );
		echo '<div class="wrap" dir="' . ( 'en' === Localization::language() ? 'ltr' : 'rtl' ) . '"><h1>' . esc_html( ( $contact ? self::t( 'بيانات التواصل العامة', 'Public contact details' ) : self::t( 'إعداد المنصة', 'Platform setup' ) ) ) . '</h1><p>' . esc_html( $contact ? self::t( 'بيانات التواصل المعروضة للزوار وصفحات الموقع. تُدار حسابات الشبكات وواتساب من قسم حسابات التواصل الاجتماعي، وبيانات البائع التجارية من إعدادات التسعير.', 'Public contact details used on site pages. Manage social accounts and WhatsApp in Social accounts, and commercial seller details in pricing settings.' ) : self::t( 'هوية المنشأة وإرسال البريد وجاهزية التشغيل. لكل مجموعة إعداداتها المستقلة، وتبقى البيانات الحالية محفوظة.', 'Business identity, email delivery and operational readiness. Each group has its own settings; existing data is preserved.' ) ) . '</p>';
		$error = get_transient( 'adc_setup_error_' . get_current_user_id() ); if ( $error ) { delete_transient( 'adc_setup_error_' . get_current_user_id() ); echo '<div class="notice notice-error"><p>' . esc_html( $error ) . '</p></div>'; }
		if ( get_transient( 'adc_setup_success_' . get_current_user_id() ) ) { delete_transient( 'adc_setup_success_' . get_current_user_id() ); echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( self::t( 'تم تنفيذ الإجراء بنجاح.', 'Action completed successfully.' ) ) . '</p></div>'; }
		if ( ! $contact && 'readiness' !== $section && ! \AutoDealership\Accounts\EmailVerification::public_link_origin() ) {
			echo '<div id="adc-verification-origin-notice" class="notice notice-warning inline"><p>' . esc_html( self::t( 'روابط تأكيد البريد واستعادة كلمة المرور تستخدم عنوان الموقع الحالي. العنوان المحلي لا يعمل من أجهزة العملاء؛ اضبط عنوان الموقع العام مع HTTPS عند النشر.', 'Verification and password reset links use the current site address. A local address is inaccessible from customer devices; configure the public HTTPS site address when deploying.' ) ) . ' <a href="' . esc_url( admin_url( 'options-general.php' ) ) . '">' . esc_html( self::t( 'إعدادات عنوان الموقع', 'Site address settings' ) ) . '</a></p></div>';
		}
		if ( ! $contact ) { echo '<nav class="nav-tab-wrapper" aria-label="' . esc_attr( self::t( 'خطوات الإعداد', 'Setup steps' ) ) . '">'; foreach ( $labels as $key=>$label ) { echo '<a class="nav-tab' . ( $key === $section ? ' nav-tab-active' : '' ) . '" href="' . esc_url( self::url( $key ) ) . '">' . esc_html( $label ) . '</a>'; } echo '</nav>'; }
		if ( in_array( $section, array( 'identity', 'appearance', 'mail' ), true ) ) {
			self::form( $section ); echo '<table class="form-table" role="presentation">';
			if ( 'identity' === $section ) {
				$p = array_replace( self::profile_defaults(), self::profile() ); $fields = array( 'brand_ar'=>array( 'اسم المنشأة بالعربية', 'Business name (Arabic)' ), 'brand_en'=>array( 'اسم المنشأة بالإنجليزية', 'Business name (English)' ), 'legal_ar'=>array( 'الاسم القانوني بالعربية (اختياري)', 'Legal name (Arabic, optional)' ), 'legal_en'=>array( 'الاسم القانوني بالإنجليزية (اختياري)', 'Legal name (English, optional)' ), 'description_ar'=>array( 'وصف الموقع بالعربية', 'Site description (Arabic)' ), 'description_en'=>array( 'وصف الموقع بالإنجليزية', 'Site description (English)' ), 'hero_ar'=>array( 'وصف الواجهة بالعربية', 'Homepage description (Arabic)' ), 'hero_en'=>array( 'وصف الواجهة بالإنجليزية', 'Homepage description (English)' ), 'language'=>array( 'اللغة الافتراضية', 'Default language' ), 'timezone'=>array( 'المنطقة الزمنية، مثل Asia/Riyadh', 'Timezone, e.g. Asia/Riyadh' ) );
				$fields['country_ar'] = array( 'الدولة بالعربية', 'Country (Arabic)' ); $fields['country_en'] = array( 'الدولة بالإنجليزية', 'Country (English)' );
				foreach ( $fields as $key=>$label ) { $default = 'brand_ar' === $key ? self::brand() : ( 'brand_en' === $key ? self::brand( 'en' ) : ( 'country_ar' === $key ? self::country( 'ar' ) : ( 'country_en' === $key ? self::country( 'en' ) : ( 'timezone' === $key ? wp_timezone_string() : ( 'language' === $key ? 'ar' : '' ) ) ) ) ); self::field( $key, self::t( ...$label ), (string) ( $p[$key] ?? $default ), 'text', 'language' === $key ? array( 'ar'=>'العربية', 'en'=>'English' ) : ( 'timezone' === $key ? array_combine( timezone_identifiers_list(), timezone_identifiers_list() ) : array() ) ); }
			} elseif ( 'appearance' === $section ) {
                $p = (array) get_option( 'car_dealer_theme_settings', array() );
                foreach ( array( 'phone'=>array( 'الهاتف', 'Phone' ), 'email'=>array( 'بريد التواصل', 'Contact email' ), 'address'=>array( 'العنوان بالعربية', 'Address (Arabic)' ), 'address_en'=>array( 'العنوان بالإنجليزية', 'Address (English)' ) ) as $key=>$label ) {
                    self::field( $key, self::t( ...$label ), (string) ( $p[$key] ?? '' ), 'email' === $key ? 'email' : 'text' );
                }
			} else {
				$mail_labels = array( 'ADC_MAIL_MODE'=>self::t( 'طريقة الإرسال', 'Mail transport' ), 'ADC_SMTP_HOST'=>self::t( 'خادم SMTP', 'SMTP host' ), 'ADC_SMTP_PORT'=>self::t( 'المنفذ', 'Port' ), 'ADC_SMTP_ENCRYPTION'=>self::t( 'تشفير الاتصال', 'Connection encryption' ), 'ADC_SMTP_USERNAME'=>self::t( 'اسم المستخدم', 'Username' ), 'ADC_SMTP_PASSWORD'=>self::t( 'كلمة مرور SMTP', 'SMTP password' ), 'ADC_MAIL_FROM'=>self::t( 'بريد المرسل', 'Sender email' ), 'ADC_MAIL_FROM_NAME'=>self::t( 'اسم المرسل', 'Sender name' ) );
				foreach ( self::MAIL_KEYS as $key ) {
					$external = !get_option('adc_product_mail_dashboard',false) && (false !== getenv( $key ) || defined( $key ));
					$value = 'ADC_SMTP_PASSWORD' === $key ? '' : ( $external ? adc_product_mail_setting( $key ) : self::mail_setting( $key, 'ADC_MAIL_MODE' === $key ? 'disabled' : ( 'ADC_SMTP_PORT' === $key ? '587' : ( 'ADC_SMTP_ENCRYPTION' === $key ? 'tls' : '' ) ) ) );
					$choices = array();
					if ( 'ADC_MAIL_MODE' === $key ) { $choices = array( 'disabled'=>self::t( 'متوقف', 'Disabled' ), 'smtp'=>self::t( 'SMTP حقيقي', 'Real SMTP' ) ); if ( in_array( wp_get_environment_type(), array( 'local', 'development' ), true ) ) { $choices['mailpit'] = 'Mailpit'; } }
					if ( 'ADC_SMTP_ENCRYPTION' === $key ) { $choices = array( 'tls'=>'STARTTLS', 'ssl'=>'TLS / SSL' ); }
					self::field( $key, $mail_labels[$key] . ( $external ? self::t( ' (محدد من الخادم)', ' (server override)' ) : '' ), $value, 'ADC_SMTP_PASSWORD' === $key ? 'password' : ( 'ADC_MAIL_FROM' === $key ? 'email' : 'text' ), $choices );
				}
			}
			echo '</table>'; submit_button( self::t( 'حفظ الإعدادات', 'Save settings' ) ); echo '</form>';
			if ( 'identity' === $section ) { self::identity_review(); }
			if ( 'mail' === $section ) { self::mail_status(); echo '<p>' . esc_html( self::t( 'الأوضاع: smtp / disabled / mailpit محليًا فقط. ترك كلمة المرور فارغة يحافظ عليها. بعد الحفظ تُعتمد إعدادات هذه الشاشة، وكلمة المرور محفوظة مشفرة ولا تدخل ملف التصدير. لبريد Gmail استخدم 587 مع STARTTLS وكلمة مرور تطبيق. تغيير مفاتيح ووردبريس يتطلب إعادة إدخال كلمة مرور SMTP.', 'Modes: smtp / disabled / mailpit (local only). Leave password blank to keep it. After saving, this screen controls mail settings. The password is encrypted and excluded from exports. For Gmail use 587 with STARTTLS and an app password. Changing WordPress salts requires re-entering SMTP credentials.' ) ) . '</p>'; self::form( 'mail', 'mail_test' ); echo '<p><label>'.esc_html(self::t('نوع الاختبار','Test type')).' <select name="test_kind"><option value="smtp">SMTP</option><option value="newsletter">'.esc_html(self::t('تصميم النشرة إلى بريد واحد','Newsletter layout to one address')).'</option></select></label></p>'; echo '<p><label>'.esc_html(self::t('لغة رسالة الاختبار','Test message language')).' <select name="test_language"><option value="ar" '.selected(Localization::language(),'ar',false).'>العربية</option><option value="en" '.selected(Localization::language(),'en',false).'>English</option></select></label></p>'; echo '<label>' . esc_html( self::t( 'عنوان رسالة الاختبار', 'Test recipient' ) ) . ' <input type="email" name="test_email" required></label>'; submit_button( self::t( 'إرسال اختبار الآن', 'Send test now' ), 'secondary' ); echo '</form>'; }
		} else {
			echo '<table class="widefat striped"><tbody>'; foreach ( self::readiness() as $label=>$ok ) { echo '<tr><th>' . esc_html( $label ) . '</th><td>' . esc_html( $ok ? self::t( 'مكتمل', 'Ready' ) : self::t( 'يحتاج مراجعة', 'Needs review' ) ) . '</td></tr>'; } echo '</tbody></table><p>' . esc_html( self::t( 'الجاهزية الآلية لا تثبت تسليم البريد أو تشغيل جدولة الخادم أو نجاح استعادة النسخ الاحتياطية؛ يجب اختبارها على الاستضافة.', 'Automatic checks do not prove email delivery, server scheduling or backup restoration; verify these on the host.' ) ) . '</p>';
            echo '<h2>' . esc_html( self::t( 'جاهزية محتوى الموقع', 'Site content readiness' ) ) . '</h2><table class="widefat striped"><thead><tr><th>' . esc_html( self::t( 'الفحص', 'Check' ) ) . '</th><th>' . esc_html( self::t( 'الحالة', 'Status' ) ) . '</th><th>' . esc_html( self::t( 'المتابعة', 'Follow up' ) ) . '</th></tr></thead><tbody>';
            foreach ( \AutoDealership\Admin\SiteContentPage::readiness() as $row ) {
                echo '<tr><th>' . esc_html( $row['name'] ) . '</th><td>' . esc_html( $row['status'] ) . '<p class="description">' . esc_html( $row['detail'] ) . '</p></td><td><a href="' . esc_url( $row['url'] ) . '">' . esc_html( self::t( 'فتح الشاشة المختصة', 'Open responsible screen' ) ) . '</a></td></tr>';
            }
            echo '</tbody></table>';
            \AutoDealership\Admin\AdminStructure::verification_sources();
            echo '<h2>' . esc_html( self::t( 'نقل إعدادات المنصة', 'Transfer platform settings' ) ) . '</h2>';
			self::form( 'readiness', 'export' ); submit_button( self::t( 'تصدير الإعدادات فقط', 'Export settings only' ), 'secondary' ); echo '</form>';
			self::form( 'readiness', 'preview', true ); echo '<label>' . esc_html( self::t( 'ملف إعدادات JSON', 'Settings JSON file' ) ) . ' <input type="file" name="settings_file" accept=".json,application/json" required></label>'; submit_button( self::t( 'معاينة الاستيراد', 'Preview import' ), 'secondary' ); echo '</form>';
			if ( isset( $_GET['preview'] ) ) { $preview = get_transient( 'adc_setup_preview_' . get_current_user_id() ); if ( is_array( $preview ) ) { echo '<h2>' . esc_html( self::t( 'مراجعة التغييرات قبل التطبيق', 'Review changes before applying' ) ) . '</h2><pre style="white-space:pre-wrap;overflow-wrap:anywhere">' . esc_html( wp_json_encode( $preview, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre>'; self::form( 'readiness', 'import' ); echo '<input type="hidden" name="preview_hash" value="' . esc_attr( hash( 'sha256', wp_json_encode( $preview ) ) ) . '">'; submit_button( self::t( 'تطبيق الإعدادات المعروضة', 'Apply displayed settings' ) ); echo '</form>'; } }
		}
		echo '</div>';
	}
}
