<?php
namespace AutoDealership\Operations;

use AutoDealership\Database\Schema;
use AutoDealership\Database\Transaction;
use AutoDealership\Security\BranchScope;
use AutoDealership\Audit\AuditLog;

defined('ABSPATH') || exit;

/** Durable staff inbox with explicit acknowledgement and permission-checked delivery. */
final class FollowUpNotifications {
	private const CLAIM_EXPIRED_NOTE = 'Claim expired before first contact; returned to shared queue';

	public static function label(string $type): string {
		if('affiliate_commission'===$type){return \AutoDealership\Core\Localization::language()==='en'?'Affiliate commission update':'تحديث عمولة المسوق';}
		if('lost_recontact'===$type){return \AutoDealership\Core\Localization::language()==='en'?'Lost lead recontact':'إعادة تواصل مع فرصة خاسرة';}
		if('lead_closed'===$type){return \AutoDealership\Core\Localization::language()==='en'?'Lead closed':'إغلاق فرصة';}
		$labels=array('new_lead'=>array('فرصة جديدة من الموقع','New website opportunity'),'lead'=>array('متابعة فرصة','Lead follow-up'),'stale_lead'=>array('فرصة راكدة','Stale lead'),'claim_expired'=>array('انتهاء مهلة استلام فرصة','Lead claim expired'),'discount'=>array('اعتماد خصم','Discount approval'),'sale'=>array('اعتماد بيع','Sale approval'),'reservation'=>array('حجز منتهي','Expired reservation'),'refund'=>array('استرداد متأخر','Overdue refund'),'outbox'=>array('مهمة آلية متعثرة','Failed background job'));
		return $labels[$type][\AutoDealership\Core\Localization::language()==='en'?1:0]??$type;
	}
	public static function url(array $row): string {
		if('affiliate_commission'===($row['source_type']??'')){return add_query_arg(array('page'=>'adc-affiliate-commissions','commission_id'=>(int)$row['source_id']),admin_url('admin.php'));}
		if('lost_recontact'===($row['source_type']??'')){return add_query_arg(array('page'=>'adc-crm','lead_id'=>(int)$row['source_id']),admin_url('admin.php'));}
		if('lead_closed'===($row['source_type']??'')){return add_query_arg(array('page'=>'adc-crm','lead_id'=>(int)$row['source_id']),admin_url('admin.php'));}
		$targets=array('new_lead'=>array('page'=>'adc-crm','lead_id'=>$row['source_id']),'lead'=>array('page'=>'adc-crm','lead_id'=>$row['source_id']),'stale_lead'=>array('page'=>'adc-crm','lead_id'=>$row['source_id']),'claim_expired'=>array('page'=>'adc-crm','lead_id'=>$row['source_id']),'discount'=>array('page'=>'adc-approvals','section'=>'discounts'),'sale'=>array('page'=>'adc-onyx-documents','sale_id'=>$row['source_id']),'reservation'=>array('page'=>'adc-sales-journey','section'=>'reservations','reservation_id'=>$row['source_id']),'refund'=>array('page'=>'adc-refunds'),'outbox'=>array('page'=>'adc-outbox'));
		return add_query_arg($targets[$row['source_type']]??array('page'=>'adc-follow-ups'),admin_url('admin.php'));
	}
	public static function boot(): void {
		OutboxService::register_handler('followup.notify',array(self::class,'deliver'));
		add_action('adc_scan_followups',array(self::class,'run'));
		add_action('admin_post_adc_ack_followup',array(self::class,'submit_acknowledgement'));
		add_action('admin_post_adc_followup_email',array(self::class,'submit_email_policy'));
	}
	public static function email_policy(bool $enabled,bool $previous) {
		global $wpdb;
		if(!current_user_can('manage_options')){return new \WP_Error('adc_followup_forbidden');}
		add_option('adc_followup_email_enabled',false,'',false);
		if(!Transaction::begin()){return new \WP_Error('adc_followup_storage');}
		$raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s FOR UPDATE",'adc_followup_email_enabled'));
		$old=(bool)maybe_unserialize($raw);
		if($wpdb->last_error||$old!==$previous){$wpdb->query('ROLLBACK');return new \WP_Error('adc_followup_stale');}
		$ok=false!==$wpdb->update($wpdb->options,array('option_value'=>$enabled?'1':''),array('option_name'=>'adc_followup_email_enabled'))&&Transaction::commit(static fn()=>AuditLog::record('followup.email_policy_changed','configuration',0,'Workflow email policy',array('enabled'=>$old),array('enabled'=>$enabled)));
		if(!$ok){$wpdb->query('ROLLBACK');}
		wp_cache_delete('adc_followup_email_enabled','options');wp_cache_delete('alloptions','options');
		return $ok?array('enabled'=>$enabled):new \WP_Error('adc_followup_storage');
	}
	public static function submit_email_policy(): void {
		check_admin_referer('adc_followup_email');
		$result=self::email_policy(($_POST['enabled']??'0')==='1',($_POST['previous']??'0')==='1');
		wp_safe_redirect(add_query_arg(is_wp_error($result)?'email_error':'email_saved',1,admin_url('admin.php?page=adc-follow-ups')));exit;
	}

	/** Definitions are code-owned; financial documents and customer names never enter mail. */
	private static function sources(): array {
		$now=current_time('mysql',true);
		$approval=gmdate('Y-m-d H:i:s',time()-DAY_IN_SECONDS);
		$refund=gmdate('Y-m-d H:i:s',time()-min(720,max(1,absint(get_option('adc_reservation_refund_hours',72))))*HOUR_IN_SECONDS);
		return array(
			'lost_recontact'=>array('SELECT l.id,l.branch_id,l.owner_user_id,l.next_action_at due_at FROM '.Schema::table('leads')." l WHERE l.stage='lost' AND l.next_action_at IS NOT NULL AND l.next_action_at<=%s",array($now),'adc_view_own_leads','adc_view_branch_leads'),
			'lead'=>array('SELECT l.id,l.branch_id,l.owner_user_id,l.next_action_at due_at FROM '.Schema::table('leads')." l WHERE l.stage NOT IN ('won','lost') AND l.next_action_at<=%s",array($now),'adc_view_own_leads','adc_view_branch_leads'),
			'stale_lead'=>array('SELECT l.id,l.branch_id,l.owner_user_id,COALESCE(MAX(a.created_at),l.updated_at,l.created_at) due_at FROM '.Schema::table('leads').' l LEFT JOIN '.Schema::table('activities').' a ON a.lead_id=l.id WHERE l.stage NOT IN (\'won\',\'lost\') GROUP BY l.id,l.branch_id,l.owner_user_id,l.updated_at,l.created_at HAVING due_at<=%s',array(gmdate('Y-m-d H:i:s',time()-max(1,absint(get_option('adc_lead_stale_days',7)))*DAY_IN_SECONDS)),'adc_view_own_leads','adc_view_branch_leads'),
			'claim_expired'=>array('SELECT a.lead_id id,h.branch_id,h.owner_user_id,a.created_at due_at FROM '.Schema::table('activities').' a INNER JOIN '.Schema::table('lead_stage_history').' h ON h.lead_id=a.lead_id AND h.changed_at=a.created_at AND h.from_stage=\'assigned\' AND h.to_stage=\'new\' AND h.owner_user_id>0 WHERE a.type=\'assignment\' AND a.notes=%s',array(self::CLAIM_EXPIRED_NOTE),'adc_view_own_leads','adc_view_branch_leads'),
			'discount'=>array('SELECT d.id,q.branch_id,0 owner_user_id,d.created_at due_at FROM '.Schema::table('discount_requests').' d INNER JOIN '.Schema::table('quotations')." q ON q.id=d.quotation_id WHERE d.status='pending' AND d.created_at<=%s",array($approval),'adc_review_discounts','adc_review_discounts'),
			'sale'=>array('SELECT s.id,v.branch_id,0 owner_user_id,s.created_at due_at FROM '.Schema::table('sales').' s INNER JOIN '.Schema::table('vehicles')." v ON v.id=s.vehicle_id WHERE s.status='pending_approval' AND s.created_at<=%s",array($approval),'adc_approve_sales','adc_approve_sales'),
			'reservation'=>array('SELECT r.id,r.branch_id,r.owner_user_id,r.expires_at due_at FROM '.Schema::table('reservations')." r WHERE r.status='confirmed' AND r.expires_at<=%s",array($now),'adc_view_own_leads','adc_view_branch_leads'),
			'refund'=>array('SELECT r.id,r.branch_id,0 owner_user_id,r.expires_at due_at FROM '.Schema::table('reservations')." r WHERE r.deposit_refund_status IN ('pending_refund','partially_refunded') AND EXISTS (SELECT 1 FROM ".Schema::table('audit_events')." a WHERE a.subject_type='reservation' AND a.subject_id=r.id AND a.event_key IN ('reservation.cancelled','reservation.expired') AND a.created_at<=%s)",array($refund),'adc_view_finance','adc_view_finance'),
			'outbox'=>array('SELECT o.id,0 branch_id,0 owner_user_id,COALESCE(o.locked_at,o.created_at) due_at FROM '.Schema::table('outbox')." o WHERE o.event_key<>'followup.notify' AND (o.status='failed' OR (o.status='processing' AND o.locked_at<=%s))",array(gmdate('Y-m-d H:i:s',time()-OutboxService::LEASE_SECONDS)),'adc_view_outbox','adc_view_outbox'),
		);
	}

	private static function allowed(array $row,int $user_id,bool $manager=false): bool {
		if('affiliate_commission'===(string)($row['source_type']??'')){
			global $wpdb;
			$commission=$wpdb->get_row($wpdb->prepare('SELECT affiliate_user_id,branch_id FROM '.Schema::table('affiliate_commissions').' WHERE id=%d',(int)$row['source_id']),ARRAY_A);
			if(!$commission||!BranchScope::allows((int)$commission['branch_id'],$user_id)){return false;}
			if($manager){return user_can($user_id,'adc_manage_affiliate_commissions')||user_can($user_id,'manage_options');}
			return (int)$commission['affiliate_user_id']===$user_id&&user_can($user_id,'adc_view_own_affiliate_commissions');
		}
		if('lead_closed'===(string)($row['source_type']??'')){return BranchScope::allows((int)$row['branch_id'],$user_id)&&($manager?user_can($user_id,'adc_view_branch_leads'):((int)$row['owner_user_id']===$user_id&&user_can($user_id,'adc_view_own_leads')));}
		if('new_lead'===(string)($row['source_type']??'')){return BranchScope::allows((int)$row['branch_id'],$user_id)&&($manager?user_can($user_id,'adc_view_branch_leads'):((int)$row['owner_user_id']>0&&(int)$row['owner_user_id']===$user_id&&user_can($user_id,'adc_view_own_leads')));}
		$source=self::sources()[$row['source_type']]??null;
		if(!$source||!BranchScope::allows((int)$row['branch_id'],$user_id)){return false;}
		if(user_can($user_id,'manage_options')){return true;}
		if($manager||!(int)$row['owner_user_id']){return user_can($user_id,$source[3]);}
		return (int)$row['owner_user_id']===$user_id&&user_can($user_id,$source[2]);
	}

	/** Queue a durable close notification for the lead owner and branch managers. */
	public static function queue_lead_closed(int $lead_id,int $branch_id,int $owner_user_id,string $stage,string $closed_at): bool {
		global $wpdb;$recipients=array();$base=array('source_type'=>'lead_closed','branch_id'=>$branch_id,'owner_user_id'=>$owner_user_id);
		if($owner_user_id>0&&self::allowed($base,$owner_user_id)){$recipients[$owner_user_id]=0;}
		foreach(get_users(array('fields'=>'ID')) as $user_id){$user_id=(int)$user_id;if($user_id!==$owner_user_id&&self::allowed($base,$user_id,true)){$recipients[$user_id]=1;}}
		foreach($recipients as $recipient=>$level){$key=hash('sha256',implode('|',array('lead_closed',$lead_id,$closed_at,$recipient,$level)));$table=Schema::table('followup_notifications');$insert=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO $table (notification_key,source_type,source_id,branch_id,owner_user_id,recipient_id,level,due_at,created_at) VALUES (%s,'lead_closed',%d,%d,%d,%d,%d,%s,%s)",$key,$lead_id,$branch_id,$owner_user_id,$recipient,$level,$closed_at,current_time('mysql',true)));if(false===$insert){return false;}if(0===$insert){continue;}$id=(int)$wpdb->insert_id;$queued=OutboxService::enqueue('followup.notify',array('subject_type'=>'followup_notification','subject_id'=>$id,'recipient_type'=>'user','recipient_id'=>$recipient,'branch_id'=>$branch_id),$key);if(is_wp_error($queued)||!AuditLog::record('followup.queued','followup_notification',$id,'Lead closed notification',null,array('recipient_id'=>$recipient,'level'=>$level,'lead_id'=>$lead_id,'stage'=>$stage))){return false;}}
		return true;
	}
	/** Queues a durable alert for a newly received public opportunity. */
	public static function queue_lead_created(int $lead_id,int $branch_id,int $owner_user_id,string $created_at): bool {
		global $wpdb;
		$base=array('source_type'=>'new_lead','branch_id'=>$branch_id,'owner_user_id'=>$owner_user_id);
		$recipients=array();
		if($owner_user_id>0&&self::allowed($base,$owner_user_id)){$recipients[$owner_user_id]=0;}
		foreach(get_users(array('fields'=>'ID')) as $user_id){$user_id=(int)$user_id;if($user_id!==$owner_user_id&&self::allowed($base,$user_id,true)){$recipients[$user_id]=1;}}
		if(!$recipients){return true;}
		$table=Schema::table('followup_notifications');
		foreach($recipients as $recipient=>$level){
			$key=hash('sha256',implode('|',array('new_lead',$lead_id,$created_at,$recipient,$level)));
			$insert=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO $table (notification_key,source_type,source_id,branch_id,owner_user_id,recipient_id,level,due_at,created_at) VALUES (%s,'new_lead',%d,%d,%d,%d,%d,%s,%s)",$key,$lead_id,$branch_id,$owner_user_id,$recipient,$level,$created_at,current_time('mysql',true)));
			if(false===$insert){return false;}
			if(0===$insert){continue;}
			$id=(int)$wpdb->insert_id;
			$queued=OutboxService::enqueue('followup.notify',array('subject_type'=>'followup_notification','subject_id'=>$id,'recipient_type'=>'user','recipient_id'=>$recipient,'branch_id'=>$branch_id),$key);
			if(is_wp_error($queued)||!AuditLog::record('followup.queued','followup_notification',$id,'New public opportunity notification',null,array('recipient_id'=>$recipient,'level'=>$level,'lead_id'=>$lead_id))){return false;}
		}
		return true;
	}

	public static function run(): void {
		$result=self::scan();
		update_option('adc_followup_health',array('finished_at'=>current_time('mysql',true),'summary'=>is_wp_error($result)?array('error'=>$result->get_error_code()):$result),false);
	}

	public static function scan() {
		global $wpdb;
		if(!Schema::is_ready()){return new \WP_Error('adc_followup_schema');}
		$users=get_users(array('fields'=>'ID'));
		$summary=array('queued'=>0,'existing'=>0,'unassigned'=>0);
		$cursors=get_option('adc_followup_cursors',array());
		foreach(self::sources() as $type=>$source){
			if('claim_expired'===$type){continue;}
			$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM ('.$source[0].') due_work WHERE id>%d ORDER BY id LIMIT 200',array_merge($source[1],array((int)($cursors[$type]??0)))),ARRAY_A);
			if($wpdb->last_error){return new \WP_Error('adc_followup_read');}
			foreach($rows as $work){
				$work['source_type']=$type;
				$escalated=strtotime($work['due_at'].' UTC')<=time()-DAY_IN_SECONDS;
				$recipients=array();
				foreach($users as $user){
					$user=(int)$user;
					if(self::allowed($work,$user)&&(!(int)$work['owner_user_id']||(int)$work['owner_user_id']===$user)){$recipients[$user]=0;}
					if($escalated&&self::allowed($work,$user,true)&&$user!==(int)$work['owner_user_id']){$recipients[$user]=1;}
				}
				if(!$recipients){++$summary['unassigned'];}
				foreach($recipients as $recipient=>$level){
					if(!Transaction::begin()){return new \WP_Error('adc_followup_storage');}
					$key=hash('sha256',implode('|',array($type,$work['id'],$work['due_at'],$recipient,$level)));
					$table=Schema::table('followup_notifications');
					$insert=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO $table (notification_key,source_type,source_id,branch_id,owner_user_id,recipient_id,level,due_at,created_at) VALUES (%s,%s,%d,%d,%d,%d,%d,%s,%s)",$key,$type,$work['id'],$work['branch_id'],$work['owner_user_id'],$recipient,$level,$work['due_at'],current_time('mysql',true)));
					if(false===$insert){$wpdb->query('ROLLBACK');return new \WP_Error('adc_followup_storage');}
					if(0===$insert){$wpdb->query('ROLLBACK');++$summary['existing'];continue;}
					$id=(int)$wpdb->insert_id;
					$queued=OutboxService::enqueue('followup.notify',array('subject_type'=>'followup_notification','subject_id'=>$id,'recipient_type'=>'user','recipient_id'=>$recipient,'branch_id'=>(int)$work['branch_id']),$key);
					if(is_wp_error($queued)||!Transaction::commit(static fn()=>AuditLog::record('followup.queued','followup_notification',$id,'Scheduled workflow reminder',null,array('recipient_id'=>$recipient,'level'=>$level)))){$wpdb->query('ROLLBACK');return new \WP_Error('adc_followup_storage');}
					++$summary['queued'];
				}
			}
			$cursors[$type]=count($rows)===200?(int)end($rows)['id']:0;
		}
		update_option('adc_followup_cursors',$cursors,false);
		return $summary;
	}

	/** Queues owner and branch-manager expiry alerts inside the lead release transaction. */
	public static function queue_claim_expired(int $lead_id,int $branch_id,int $owner_user_id,string $expired_at): bool {
		global $wpdb;
		$work=array('id'=>$lead_id,'source_id'=>$lead_id,'source_type'=>'claim_expired','branch_id'=>$branch_id,'owner_user_id'=>$owner_user_id,'due_at'=>$expired_at);
		$recipients=array();
		if(self::allowed($work,$owner_user_id)){$recipients[$owner_user_id]=0;}
		foreach(get_users(array('fields'=>'ID')) as $user_id){
			$user_id=(int)$user_id;
			if($user_id!==$owner_user_id&&self::allowed($work,$user_id,true)){$recipients[$user_id]=1;}
		}
		if(!$recipients){error_log('Auto Dealership Core: no authorized recipient for expired CRM claim alert.');return true;}
		$table=Schema::table('followup_notifications');
		foreach($recipients as $recipient=>$level){
			$key=hash('sha256',implode('|',array('claim_expired',$lead_id,$expired_at,$recipient,$level)));
			$insert=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO $table (notification_key,source_type,source_id,branch_id,owner_user_id,recipient_id,level,due_at,created_at) VALUES (%s,'claim_expired',%d,%d,%d,%d,%d,%s,%s)",$key,$lead_id,$branch_id,$owner_user_id,$recipient,$level,$expired_at,current_time('mysql',true)));
			if(false===$insert){return false;}
			if(0===$insert){continue;}
			$id=(int)$wpdb->insert_id;
			$queued=OutboxService::enqueue('followup.notify',array('subject_type'=>'followup_notification','subject_id'=>$id,'recipient_type'=>'user','recipient_id'=>(int)$recipient,'branch_id'=>$branch_id),$key);
			if(is_wp_error($queued)||!AuditLog::record('followup.queued','followup_notification',$id,'Expired CRM lead claim alert',null,array('recipient_id'=>(int)$recipient,'level'=>$level))){return false;}
		}
		return true;
	}

	/** Queue an affiliate-facing inbox/email notification inside the caller's transaction. */
	public static function queue_affiliate_commission(int $commission_id,string $event): bool {
		global $wpdb;
		$row=$wpdb->get_row($wpdb->prepare('SELECT id,affiliate_user_id,branch_id,status,updated_at FROM '.Schema::table('affiliate_commissions').' WHERE id=%d FOR UPDATE',$commission_id),ARRAY_A);
		if(!$row||$wpdb->last_error){return false;}
		$affiliate_context=array('source_type'=>'affiliate_commission','source_id'=>$commission_id,'branch_id'=>(int)$row['branch_id'],'owner_user_id'=>(int)$row['affiliate_user_id']);
		$recipients=array();
		$preference_event = 0 === strpos( $event, 'status_' ) ? substr( $event, 7 ) : $event;
		if ( ! in_array( $preference_event, array( 'created', 'approved', 'paid', 'void', 'returned' ), true ) ) { $preference_event = 'created'; }
		if(self::allowed($affiliate_context,(int)$row['affiliate_user_id']) && \AutoDealership\Marketing\AffiliateNotificationPreferences::accepts((int)$row['affiliate_user_id'],$preference_event,'inbox')){$recipients[(int)$row['affiliate_user_id']]=0;}
		if(in_array($event,array('created','returned'),true)){
			foreach(get_users(array('fields'=>'ID')) as $user_id){$user_id=(int)$user_id;if($user_id!==(int)$row['affiliate_user_id']&&self::allowed($affiliate_context,$user_id,true) && \AutoDealership\Marketing\AffiliateNotificationPreferences::accepts($user_id,$preference_event,'inbox')){$recipients[$user_id]=1;}}
		}
		$table=Schema::table('followup_notifications');
		foreach($recipients as $recipient=>$level){
			$key=hash('sha256',implode('|',array('affiliate_commission',$commission_id,$event,$recipient,$level,$row['status'])));
			$insert=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO $table (notification_key,source_type,source_id,branch_id,owner_user_id,recipient_id,level,due_at,created_at) VALUES (%s,'affiliate_commission',%d,%d,%d,%d,%d,%s,%s)",$key,$commission_id,(int)$row['branch_id'],(int)$row['affiliate_user_id'],$recipient,$level,(string)$row['updated_at'],current_time('mysql',true)));
			if(false===$insert){return false;}
			if(0===$insert){continue;}
			$id=(int)$wpdb->insert_id;
			$queued=OutboxService::enqueue('followup.notify',array('subject_type'=>'followup_notification','subject_id'=>$id,'recipient_type'=>'user','recipient_id'=>$recipient,'branch_id'=>(int)$row['branch_id']),$key);
			if(is_wp_error($queued)||!AuditLog::record('affiliate_commission.notification_queued','followup_notification',$id,'Affiliate commission notification',null,array('commission_id'=>$commission_id,'event'=>$event,'recipient_id'=>$recipient))){return false;}
		}
		return true;
	}

	private static function current(array $row) {
		global $wpdb;
		if('affiliate_commission'===(string)$row['source_type']){$commission=$wpdb->get_row($wpdb->prepare('SELECT id,affiliate_user_id,branch_id FROM '.Schema::table('affiliate_commissions').' WHERE id=%d',(int)$row['source_id']),ARRAY_A);return $commission&&(int)$commission['branch_id']===(int)$row['branch_id'];}
		if('new_lead'===(string)$row['source_type']){$lead=$wpdb->get_row($wpdb->prepare('SELECT id,branch_id,owner_user_id,stage,archived_at,created_at FROM '.Schema::table('leads').' WHERE id=%d',(int)$row['source_id']),ARRAY_A);return $lead&&empty($lead['archived_at'])&&!in_array($lead['stage'],array('won','lost'),true)&&(int)$lead['branch_id']===(int)$row['branch_id']&&(int)$lead['owner_user_id']===(int)$row['owner_user_id']&&(string)$lead['created_at']===(string)$row['due_at'];}
		if('lost_recontact'===(string)$row['source_type']){$lead=$wpdb->get_row($wpdb->prepare('SELECT id,branch_id,owner_user_id,stage,next_action_at FROM '.Schema::table('leads').' WHERE id=%d',(int)$row['source_id']),ARRAY_A);return $lead&&'lost'===$lead['stage']&&(string)$lead['next_action_at']===(string)$row['due_at']&&(int)$lead['branch_id']===(int)$row['branch_id'];}
		if('lead_closed'===(string)$row['source_type']){$lead=$wpdb->get_row($wpdb->prepare('SELECT id,branch_id,owner_user_id,stage,closed_at FROM '.Schema::table('leads').' WHERE id=%d',(int)$row['source_id']),ARRAY_A);return $lead&&in_array($lead['stage'],array('won','lost'),true)&&(string)$lead['closed_at']===(string)$row['due_at']&&(int)$lead['branch_id']===(int)$row['branch_id'];}
		$source=self::sources()[$row['source_type']]??null;
		if(!$source){return false;}
		if('claim_expired'===$row['source_type']){
			$exists=$wpdb->get_var($wpdb->prepare('SELECT a.id FROM '.Schema::table('activities').' a INNER JOIN '.Schema::table('lead_stage_history').' h ON h.lead_id=a.lead_id AND h.changed_at=a.created_at AND h.from_stage=\'assigned\' AND h.to_stage=\'new\' WHERE a.lead_id=%d AND a.type=\'assignment\' AND a.notes=%s AND a.created_at=%s AND h.branch_id=%d AND h.owner_user_id=%d LIMIT 1',(int)$row['source_id'],self::CLAIM_EXPIRED_NOTE,$row['due_at'],(int)$row['branch_id'],(int)$row['owner_user_id']));
			if($wpdb->last_error){return new \WP_Error('adc_followup_read');}
			return (bool)$exists;
		}
		$work=$wpdb->get_row($wpdb->prepare('SELECT * FROM ('.$source[0].') due_work WHERE id=%d',array_merge($source[1],array((int)$row['source_id']))),ARRAY_A);
		if($wpdb->last_error){return new \WP_Error('adc_followup_read');}
		return $work&&$work['due_at']===$row['due_at']&&(int)$work['branch_id']===(int)$row['branch_id']&&(int)$work['owner_user_id']===(int)$row['owner_user_id'];
	}

	public static function deliver(array $payload) {
		global $wpdb;
		$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.Schema::table('followup_notifications').' WHERE id=%d',(int)($payload['subject_id']??0)),ARRAY_A);
		if($wpdb->last_error){return new \WP_Error('adc_followup_read');}
		if(!$row){return new \WP_Error('adc_outbox_payload');}
		if($row['delivered_at']||$row['acknowledged_at']){return true;}
		$current=self::current($row);if(is_wp_error($current)){return $current;}
		if(!$current||!self::allowed($row,(int)$row['recipient_id'],(bool)$row['level'])){return false!==$wpdb->update(Schema::table('followup_notifications'),array('resolved_at'=>current_time('mysql',true)),array('id'=>$row['id']));}
		$channel='inbox';
		if(get_option('adc_followup_email_enabled',false)){
			$subject='';
			$message='';
			$user=get_userdata((int)$row['recipient_id']);
			if('affiliate_commission'!==$row['source_type'] && (!$user||!is_email($user->user_email))){return new \WP_Error('adc_followup_recipient');}
			if('affiliate_commission'===$row['source_type']){
				$commission=$wpdb->get_row($wpdb->prepare('SELECT id,status,amount,currency_code FROM '.Schema::table('affiliate_commissions').' WHERE id=%d',(int)$row['source_id']),ARRAY_A);
				$event='pending_review'===(string)($commission['status']??'')?'created':('approved'===(string)($commission['status']??'')?'approved':('paid'===(string)($commission['status']??'')?'paid':('void'===(string)($commission['status']??'')?'void':'returned')));
				if ( ! \AutoDealership\Marketing\AffiliateNotificationPreferences::accepts((int)$row['recipient_id'],$event,'email') ) { $channel='inbox'; }
				else {
				if(!$user||!is_email($user->user_email)){return new \WP_Error('adc_followup_recipient');}
				$subject='تحديث عمولة المسوق / Affiliate commission update';
				$message='تم تحديث حالة عمولتك. راجع صفحة عمولات المسوقين للاطلاع على الحالة الحالية. / Your affiliate commission status was updated. Review the affiliate commission page for the current status: ';
				$url=admin_url('admin.php?page=adc-affiliate-commissions&commission_id='.(int)$row['source_id']);
				$lang=\AutoDealership\Leads\NewsletterService::language((string)get_user_meta((int)$row['recipient_id'],'adc_preferred_language',true));$ar='ar'===$lang;
				$title=$ar?'تحديث عمولة المسوق':'Affiliate commission update';$body='<p>'.esc_html($ar?'تم تحديث حالة عمولتك. راجع صفحة العمولات للاطلاع على التفاصيل.':'Your affiliate commission status was updated. Review the commission page for details.').'</p>';
				$html=\AutoDealership\Accounts\BrandedMail::render($title,$body,$ar?'عرض العمولات':'View commissions',$url,'',$lang);
				$template=\AutoDealership\Marketing\AffiliateCommissionNotificationTemplate::build($commission?:array('id'=>(int)$row['source_id'],'status'=>'pending_review','amount'=>0,'currency_code'=>'SAR'),$event,(int)$row['recipient_id']);
				$subject=$template['subject'];$html=\AutoDealership\Accounts\BrandedMail::render($template['title'],$template['body'],$template['button'],$template['url'],'',$template['language']);
				if(!\AutoDealership\Accounts\BrandedMail::send($user->user_email,$subject,$html)){return new \WP_Error('adc_affiliate_mail');}
				$channel='email'; }
			}elseif('new_lead'===$row['source_type']){
				$subject='فرصة جديدة من الموقع / New website opportunity';
				$message='وصلت فرصة جديدة من أحد نماذج الموقع. افتحها من لوحة CRM لمراجعتها وإسنادها: ';
			}elseif('claim_expired'===$row['source_type']){
				$subject='انتهاء مهلة استلام فرصة CRM / CRM lead claim expired';
				$message='انتهت مهلة استلام فرصة CRM وأعيدت إلى قائمة الفرع المشتركة. راجع لوحة المتابعات. / A CRM lead claim expired and the lead returned to the branch queue. Review the follow-up inbox: ';
			}else{
				$subject='متابعة عمل مستحقة / Due workflow follow-up';
				$message='توجد متابعة مستحقة ضمن صلاحياتك. افتح لوحة المتابعات للاطلاع والإقرار. / Review and acknowledge your due work: ';
			}
			if('affiliate_commission'!==$row['source_type'] && !wp_mail($user->user_email,$subject,$message.admin_url('admin.php?page=adc-follow-ups'))){return new \WP_Error('adc_followup_mail');}
			if('affiliate_commission'!==$row['source_type']){$channel='email';}
		}
		return false!==$wpdb->update(Schema::table('followup_notifications'),array('delivered_at'=>current_time('mysql',true),'delivery_channel'=>$channel),array('id'=>$row['id']));
	}

	public static function acknowledge(int $id) {
		global $wpdb;
		if(!Transaction::begin()){return new \WP_Error('adc_followup_storage');}
		$table=Schema::table('followup_notifications');
		$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d FOR UPDATE",$id),ARRAY_A);
		if(!$row||(int)$row['recipient_id']!==get_current_user_id()||!self::allowed($row,get_current_user_id(),(bool)$row['level'])){$wpdb->query('ROLLBACK');return new \WP_Error('adc_followup_forbidden');}
		if($row['acknowledged_at']){$wpdb->query('ROLLBACK');return array('acknowledged'=>true);}
		$ok=1===$wpdb->update($table,array('acknowledged_at'=>current_time('mysql',true)),array('id'=>$id))&&Transaction::commit(static fn()=>AuditLog::record('followup.acknowledged','followup_notification',$id,'Staff acknowledged reminder',null,array('recipient_id'=>get_current_user_id())));
		if(!$ok){$wpdb->query('ROLLBACK');return new \WP_Error('adc_followup_storage');}
		return array('acknowledged'=>true);
	}

	public static function submit_acknowledgement(): void {
		$id=absint($_POST['id']??0);check_admin_referer('adc_ack_followup_'.$id);
		$result=self::acknowledge($id);
		wp_safe_redirect(add_query_arg(is_wp_error($result)?'ack_error':'acknowledged',1,admin_url('admin.php?page=adc-follow-ups')));exit;
	}

	public static function inbox(): array { $page = self::inbox_page( array( 'page'=>1, 'per_page'=>100 ) ); return is_wp_error( $page ) ? array() : $page['items']; }

	public static function inbox_page( array $filters = array() ) {
		global $wpdb; $page=max(1,absint($filters['page']??1));$per_page=min(100,max(1,absint($filters['per_page']??25)));$where=array('recipient_id=%d');$args=array(get_current_user_id());
		if(!empty($filters['archived'])){$where[]='(acknowledged_at IS NOT NULL OR resolved_at IS NOT NULL)';}else{$where[]='acknowledged_at IS NULL AND resolved_at IS NULL';}
		if(!empty($filters['source_type'])){$where[]='source_type=%s';$args[]=sanitize_key((string)$filters['source_type']);}
		if(isset($filters['search'])&&''!==trim((string)$filters['search'])){$where[]='CAST(source_id AS CHAR) LIKE %s';$args[]='%'.$wpdb->esc_like(sanitize_text_field((string)$filters['search'])).'%';}
		$table=Schema::table('followup_notifications');$base=implode(' AND ',$where);$total=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE $base",$args));$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE $base ORDER BY id DESC LIMIT %d OFFSET %d",array_merge($args,array($per_page,($page-1)*$per_page))),ARRAY_A)?:array();$result=array();foreach($rows as $row){if(!self::allowed($row,get_current_user_id(),(bool)$row['level'])){continue;}$current=self::current($row);if(is_wp_error($current)){return $current;}if($current||!empty($filters['archived'])){$result[]=$row;}}
		return array('items'=>$result,'page'=>$page,'per_page'=>$per_page,'total'=>$total,'pages'=>(int)ceil($total/$per_page),'timezone'=>wp_timezone_string());
	}
}
