<?php
/**
 * قالب صفحة تواصل معنا
 *
 * @package WordPress
 * @subpackage Car_Dealer
 * @since Car Dealer 2.0
 * Template Name: صفحة تواصل معنا
 */
get_header(); ?>

<div class="page-template-contact">
<div class="container">
	<div class="content-area">
		<div id="main" class="site-main">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<header class="entry-header"><?php the_title( '<h1 class="entry-title">', '</h1>' ); ?></header>
					<?php if ( has_post_thumbnail() ) : ?>
						<div class="entry-image">
							<?php the_post_thumbnail( 'large' ); ?>
						</div>
					<?php endif; ?>
					<div class="entry-content">
						<?php the_content(); ?>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
	</div>
</div>
</div>

<style>
.page-template-contact .content-area { max-width: 100%; padding: 0; }
.page-template-contact .entry-content { max-width: 100%; }
</style>

<?php get_footer(); ?>
